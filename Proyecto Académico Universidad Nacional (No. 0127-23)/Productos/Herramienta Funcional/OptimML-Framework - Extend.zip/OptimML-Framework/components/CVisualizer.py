import dash
from dash import html, dcc, dash_table
from dash.dependencies import Input, Output
import plotly.graph_objs as go
import plotly.express as px
from sklearn.exceptions import ConvergenceWarning
import warnings
import threading
import seaborn as sns
import pandas as pd
import numpy as np
from sqlalchemy import create_engine, URL
from sqlalchemy_utils import database_exists, create_database
import pymssql
import time
warnings.filterwarnings("ignore", category=ConvergenceWarning)
warnings.filterwarnings("ignore", category=UserWarning)
import os 
import matplotlib.pyplot as plt
import seaborn as sns
from . import CGenerator as cG
from . import CEvaluator as cE
from . import CPredictor as cP
import streamlit as st
from streamlit_option_menu import option_menu
from datetime import datetime
import json
from .utils.print_utils import (
    print_section_header, print_subsection_header, print_info, 
    print_success, print_warning, print_error, print_progress
)

"""
Data Visualization and Dashboard Module

This module provides functionality for visualizing model evaluation results and creating
interactive dashboards. It includes utilities for loading and processing data, training models,
and creating various visualizations to compare model performance across different algorithms
and optimization approaches.
"""

@st.cache_data
def load_and_process_data(csv_files, use_sql, db_params):
    """
    Load and process data from CSV files or SQL database.
    
    This function uses the DataGenerator to load data from either CSV files or a SQL database,
    process it, and prepare train/test splits for model training.
    
    Args:
        csv_files (list): List of paths to CSV files
        use_sql (bool): Whether to use SQL database for data storage
        db_params (dict): Database connection parameters if use_sql is True
        
    Returns:
        tuple: (X_trains, X_tests, y_trains, y_tests, dfs) containing:
            - X_trains (dict): Dictionary of training feature sets by dataset name
            - X_tests (dict): Dictionary of testing feature sets by dataset name
            - y_trains (dict): Dictionary of training target values by dataset name
            - y_tests (dict): Dictionary of testing target values by dataset name
            - dfs (dict): Dictionary of original dataframes by dataset name
    """
    print_subsection_header("Data Loading and Processing")
    
    data_gen = cG.DataGenerator(csv_files, use_sql=use_sql, db_params=db_params)
    data_gen.process()
    X_trains, X_tests, y_trains, y_tests = data_gen.get_data()
    
    print_success("Data loading and processing complete")
    
    return X_trains, X_tests, y_trains, y_tests, data_gen.dfs

@st.cache_data
def train_models(X_trains, X_tests, y_trains, y_tests):
    """
    Train models using genetic, PSO, CDEA, ABC, GWO, and WOA search methods.

    This function trains models for each dataset using bioinspired hyperparameter
    optimization strategies and evaluates their performance.

    Args:
        X_trains (dict): Dictionary of training feature sets by dataset name
        X_tests (dict): Dictionary of testing feature sets by dataset name
        y_trains (dict): Dictionary of training target values by dataset name
        y_tests (dict): Dictionary of testing target values by dataset name

    Returns:
        tuple: Results and evaluation dictionaries for each optimization strategy.
    """
    print_section_header("Model Training")

    results_genetic = {}
    results_pso = {}
    results_cdea = {}
    results_abc = {}
    results_gwo = {}
    results_woa = {}

    for dataset_name in X_trains.keys():
        print_subsection_header(f"Training models for dataset: {dataset_name}")

        evaluator = cE.ModelEvaluator(
            X_trains[dataset_name], X_tests[dataset_name],
            y_trains[dataset_name], y_tests[dataset_name]
        )

        results_genetic[dataset_name] = evaluator.genetic_search()
        results_pso[dataset_name] = evaluator.pso_search()
        results_cdea[dataset_name] = evaluator.cdea_search()
        results_abc[dataset_name] = evaluator.abc_search()
        results_gwo[dataset_name] = evaluator.gwo_search()
        results_woa[dataset_name] = evaluator.woa_search()

    genetic_evaluation = {}
    pso_evaluation = {}
    cdea_evaluation = {}
    abc_evaluation = {}
    gwo_evaluation = {}
    woa_evaluation = {}

    for dataset_name in X_trains.keys():
        predictor = cP.Predictor(X_tests[dataset_name], y_tests[dataset_name])
        genetic_evaluation[dataset_name] = predictor.evaluate_results(results_genetic[dataset_name])
        pso_evaluation[dataset_name] = predictor.evaluate_results(results_pso[dataset_name])
        cdea_evaluation[dataset_name] = predictor.evaluate_results(results_cdea[dataset_name])
        abc_evaluation[dataset_name] = predictor.evaluate_results(results_abc[dataset_name])
        gwo_evaluation[dataset_name] = predictor.evaluate_results(results_gwo[dataset_name])
        woa_evaluation[dataset_name] = predictor.evaluate_results(results_woa[dataset_name])

    print_success("Model training complete")

    return (
        results_genetic,
        results_pso,
        results_cdea,
        results_abc,
        results_gwo,
        results_woa,
        genetic_evaluation,
        pso_evaluation,
        cdea_evaluation,
        abc_evaluation,
        gwo_evaluation,
        woa_evaluation
    )


class Visualizer:
    """
    Visualizer class responsible for creating interactive dashboards and visualizations.

    This class provides methods to create various visualizations and dashboards to compare
    model performance across bioinspired optimization approaches. It handles
    the presentation of results in a user-friendly format using Streamlit.

    Attributes:
        results_genetic (dict): Results from genetic algorithm optimization
        results_pso (dict): Results from PSO optimization
        results_cdea (dict): Results from CDEA optimization
        results_abc (dict): Results from ABC optimization
        results_gwo (dict): Results from GWO optimization
        results_woa (dict): Results from WOA optimization
        dfs (dict): Dictionary of original dataframes by dataset name
    """

    def __init__(
        self,
        results_genetic,
        results_pso,
        results_cdea,
        results_abc,
        results_gwo,
        results_woa,
        dfs
    ):
        """
        Initialize the Visualizer with model results and data.

        Args:
            results_genetic (dict): Results from genetic algorithm optimization
            results_pso (dict): Results from PSO optimization
            results_cdea (dict): Results from CDEA optimization
            results_abc (dict): Results from ABC optimization
            results_gwo (dict): Results from Grey Wolf Optimizer optimization
            results_woa (dict): Results from Whale Optimization Algorithm optimization
            dfs (dict): Dictionary of original dataframes by dataset name
        """
        self.results_genetic = results_genetic
        self.results_pso = results_pso
        self.results_cdea = results_cdea
        self.results_abc = results_abc
        self.results_gwo = results_gwo
        self.results_woa = results_woa
        self.dfs = dfs
        
    def ensure_arrow_compatible(self, df):
        """
        Ensure dataframe is compatible with Arrow for Streamlit.
        
        This method converts DataFrame columns to types that are compatible with
        Apache Arrow, which is used by Streamlit for data transfer. This helps
        prevent errors when displaying DataFrames in the Streamlit interface.
        
        Args:
            df (DataFrame): Input DataFrame to convert
            
        Returns:
            DataFrame: New DataFrame with Arrow-compatible data types
        """
        # Create a new DataFrame with explicit types that Arrow can handle
        new_df = pd.DataFrame()
        
        # Process each column with the appropriate type conversion
        for col in df.columns:
            # Get the column data
            col_data = df[col]
            
            # Check data type and convert appropriately
            if pd.api.types.is_integer_dtype(col_data):
                # Convert integers to standard Python int
                new_df[col] = col_data.astype('int64')
            elif pd.api.types.is_float_dtype(col_data):
                # Convert floats to standard Python float
                new_df[col] = col_data.astype('float64')
            elif pd.api.types.is_bool_dtype(col_data):
                # Convert to standard Python bool
                new_df[col] = col_data.astype('bool')
            else:
                # Convert everything else to string
                new_df[col] = col_data.astype(str)
                
        return new_df

    def create_results_dataframe(self):
        """
        Create a summary DataFrame with model performance results.
        
        This method compiles the results from multiple search approaches into a
        single DataFrame for easy comparison, including RMSE and training time for
        each algorithm and dataset.
        
        Returns:
            DataFrame: Summary DataFrame with model performance metrics
        """
        data = []
        methods = [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]

        for dataset_name in self.results_genetic.keys():
            for alg in self.results_genetic[dataset_name].keys():
                row = {
                    'Dataset': dataset_name,
                    'Algorithm': alg
                }
                for label, results in methods:
                    time_value = results[dataset_name][alg].get('training_time', 0)
                    row[f'RMSE ({label})'] = results[dataset_name][alg]['rmse']
                    row[f'Time ({label[0]})'] = f"{time_value:.2f} s"
                data.append(row)

        df = pd.DataFrame(data)
        sort_cols = [f'RMSE ({label})' for label, _ in methods]
        df.sort_values(by=sort_cols, ascending=True, inplace=True)
        df = self.ensure_arrow_compatible(df)
        return df
    
    def create_detailed_results_dataframe(self):
        """
        Create a detailed DataFrame with all results for export to Excel.
        
        This method creates a comprehensive DataFrame with detailed information
        about each model's performance, including hyperparameters, RMSE, and
        training time for every search approach.
        
        Returns:
            DataFrame: Detailed DataFrame with model performance and hyperparameters
        """
        data = []
        methods = [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]

        for dataset_name in self.results_genetic.keys():
            for alg in self.results_genetic[dataset_name].keys():
                row = {
                    'Dataset': dataset_name,
                    'Algorithm': alg
                }
                for label, results in methods:
                    params = json.dumps(results[dataset_name][alg]['best_params'])
                    training_time = results[dataset_name][alg].get('training_time', 0)
                    row[f'RMSE ({label})'] = results[dataset_name][alg]['rmse']
                    row[f'Hyperparameters ({label})'] = params
                    row[f'Training Time ({label})'] = f"{training_time:.2f} seconds"
                data.append(row)

        df = pd.DataFrame(data)
        df = self.ensure_arrow_compatible(df)
        return df
    
    def create_best_hyperparams_dataframe(self):
        """
        Create a DataFrame with hyperparameters of the best model by RMSE.
        
        This method identifies the dataset and algorithm with the best overall RMSE
        performance and creates a DataFrame with the hyperparameters for all search
        approaches for that best model.
        
        Returns:
            tuple: (DataFrame, str) - DataFrame with hyperparameters of the best performing model,
                   and the name of the best algorithm
        """
        data = []
        best_dataset = None
        best_algorithm = None
        best_rmse = float('inf')
        methods = [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]

        for dataset_name in self.results_genetic.keys():
            for alg in self.results_genetic[dataset_name].keys():
                for label, results in methods:
                    score = results[dataset_name][alg]['rmse']
                    if score < best_rmse:
                        best_rmse = score
                        best_dataset = dataset_name
                        best_algorithm = alg

        if best_dataset and best_algorithm:
            for label, results in methods:
                best_result = results[best_dataset][best_algorithm]
                entry = {
                    'Dataset': best_dataset,
                    'Approach': label,
                    'Algorithm': best_algorithm,
                    'RMSE': best_result['rmse'],
                    'Time (seconds)': best_result.get('training_time', 0)
                }
                for param, value in best_result['best_params'].items():
                    entry[param] = value
                data.append(entry)

        df = pd.DataFrame(data)
        df = self.ensure_arrow_compatible(df)
        return df, best_algorithm
    
    def create_best_algorithms_dataframe(self):
        """
        Create a DataFrame with the 3 best algorithms by RMSE overall.
        
        This method collects all algorithm results from all datasets, sorts them by RMSE,
        and returns the top 3 algorithms.
        
        Returns:
            DataFrame: DataFrame with the top 3 algorithms by RMSE
        """
        data = []
        methods = [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]

        all_results = []
        for dataset_name in self.results_genetic.keys():
            for alg in self.results_genetic[dataset_name].keys():
                for label, results in methods:
                    all_results.append({
                        'Dataset': dataset_name,
                        'Algorithm': alg,
                        'RMSE': results[dataset_name][alg]['rmse'],
                        'Approach': label
                    })

        all_results.sort(key=lambda x: x['RMSE'])
        top_algorithms = all_results[:3] if len(all_results) >= 3 else all_results

        for result in top_algorithms:
            data.append({
                'Dataset': result['Dataset'],
                'Algorithm': result['Algorithm'],
                'RMSE': result['RMSE'],
                'Approach': result['Approach']
            })

        df = pd.DataFrame(data)
        df = self.ensure_arrow_compatible(df)
        return df

    def create_best_dataset_per_algorithm(self):
        """
        Identify the best dataset for each bioinspired optimization method.

        For each bioinspired method (Genetic, PSO, CDEA, ABC, GWO, WOA) this method finds
        the dataset and underlying algorithm that achieved the lowest RMSE.

        Returns:
            DataFrame: Rows with columns ['Method','Dataset','Algorithm','RMSE','Training Time']
        """
        methods = [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]

        rows = []
        for label, results in methods:
            best_rmse = float('inf')
            best_dataset = None
            best_algorithm = None
            best_time = 0
            for dataset_name in results.keys():
                for alg in results[dataset_name].keys():
                    try:
                        rmse = results[dataset_name][alg].get('rmse', float('inf'))
                    except Exception:
                        rmse = float('inf')
                    if rmse < best_rmse:
                        best_rmse = rmse
                        best_dataset = dataset_name
                        best_algorithm = alg
                        best_time = results[dataset_name][alg].get('training_time', 0)

            if best_dataset is not None:
                rows.append({
                    'Method': label,
                    'Dataset': best_dataset,
                    'Algorithm': best_algorithm,
                    'RMSE': best_rmse,
                    'Training Time (s)': f"{best_time:.2f}"
                })

        df = pd.DataFrame(rows)
        df = self.ensure_arrow_compatible(df)
        return df

    def create_best_algorithms_by_dataset(self):
        """
        Create a DataFrame with the best bioinspired algorithm for each dataset.

        This method finds the best algorithm for each dataset within each
        bioinspired optimization method (Genetic, PSO, CDEA, ABC, GWO, WOA),
        ranked by the lowest RMSE.

        Returns:
            DataFrame: Rows with columns ['Dataset','Method','Algorithm','RMSE','Training Time (s)']
        """
        methods = [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]

        rows = []
        for dataset_name in self.results_genetic.keys():
            for label, results in methods:
                best_rmse = float('inf')
                best_algorithm = None
                best_time = 0
                if dataset_name not in results:
                    continue
                for alg, result in results[dataset_name].items():
                    rmse = result.get('rmse', float('inf'))
                    if rmse < best_rmse:
                        best_rmse = rmse
                        best_algorithm = alg
                        best_time = result.get('training_time', 0)

                if best_algorithm is not None:
                    rows.append({
                        'Dataset': dataset_name,
                        'Method': label,
                        'Algorithm': best_algorithm,
                        'RMSE': best_rmse,
                        'Training Time (s)': f"{best_time:.2f}"
                    })

        df = pd.DataFrame(rows)
        df = self.ensure_arrow_compatible(df)
        return df

    def export_results_to_excel(self):
        """
        Export the results to an Excel file.
        
        This method creates an Excel file with three sheets: General Results, Best Model,
        and Top 3 Algorithms.
        
        Returns:
            str: Path to the generated Excel file
        """
        df_general = self.create_detailed_results_dataframe()
        df_best_hyperparams, best_algorithm = self.create_best_hyperparams_dataframe()
        df_best_algorithms = self.create_best_algorithms_dataframe()
        df_best_by_dataset = self.create_best_algorithms_by_dataset()
        
        # Create directory for results if it doesn't exist
        # Adjust path to be relative to the project root, not the components directory
        results_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")
        os.makedirs(results_dir, exist_ok=True)
        
        # Filename with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(results_dir, f"framework_results_{timestamp}.xlsx")
        
        # Create an ExcelWriter for the main file
        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            # Write the main table
            df_general.to_excel(writer, sheet_name='General Results', index=False)
            
            # Write the best hyperparameters table
            best_hyperparams_sheet = f"Best Model - {best_algorithm}"
            df_best_hyperparams.to_excel(writer, sheet_name=best_hyperparams_sheet, index=False)
            
            # Write the best algorithms table
            df_best_algorithms.to_excel(writer, sheet_name='Top 3 Algorithms', index=False)
            
            # Write best algorithm per dataset table
            df_best_by_dataset.to_excel(writer, sheet_name='Best By Dataset', index=False)
            
            # Adjust the column width for each sheet
            for sheet_name in writer.sheets:
                worksheet = writer.sheets[sheet_name]
                df = None
                
                if sheet_name == 'General Results':
                    df = df_general
                elif sheet_name == best_hyperparams_sheet:
                    df = df_best_hyperparams
                elif sheet_name == 'Top 3 Algorithms':
                    df = df_best_algorithms
                elif sheet_name == 'Best By Dataset':
                    df = df_best_by_dataset
                
                if df is not None:
                    for i, col in enumerate(df.columns):
                        max_length = max(df[col].astype(str).map(len).max(), len(col)) + 2
                        worksheet.column_dimensions[chr(65 + i)].width = max_length
        
        return filename

    def create_correlation_heatmap(self, dataset_name):
        """
        Create a correlation heatmap for a specific dataset.
        
        This method generates a heatmap showing the correlation between features in the
        specified dataset.
        
        Args:
            dataset_name (str): Name of the dataset to create the heatmap for
        
        Returns:
            plotly.graph_objs.Figure: Heatmap figure
        """
        if dataset_name not in self.dfs:
            return go.Figure()  
        
        corr = self.dfs[dataset_name].corr()
        fig = px.imshow(corr, 
                        labels=dict(color="Correlation"),
                        x=corr.columns,
                        y=corr.columns,
                        color_continuous_scale="RdBu_r",
                        zmin=-1, zmax=1)
        fig.update_layout(title=f"Correlation Heatmap - {dataset_name}")
        st.plotly_chart(fig)
        
    def create_dashboard(self):        
        with st.sidebar:
            selected = option_menu(
                menu_title="Main Menu",
                options=["Exploratory Data Analysis", "Results"],
                menu_icon="cast",
                default_index=0,
            )

        if selected == "Exploratory Data Analysis":
            self.page_eda()
        elif selected == "Results":
            self.page_model_results()
            
    def page_eda(self):
        """
        Create the Exploratory Data Analysis page.
        
        This method generates a page with various visualizations and statistics for
        exploratory data analysis.
        """
        st.title("Exploratory Data Analysis")

        selected_dataset = st.selectbox("Select the dataset:", list(self.dfs.keys()))

        if selected_dataset:
            data = self.dfs[selected_dataset]
            melted_data = data.melt()

            st.subheader("Data Description")
            st.write("Data Types:")
            st.write(data.dtypes)
            st.write("Missing Values:")
            st.write(data.isnull().sum())
            st.write("Statistical Description:")
            st.write(data.describe())


            st.subheader("Histogram")
            fig = px.histogram(melted_data, x="value", color="variable", marginal="box", hover_data=['variable'])
            st.plotly_chart(fig)

            st.subheader("Boxplot")
            fig = px.box(melted_data, y="value", color="variable", points="all", hover_data=['variable'])
            st.plotly_chart(fig)

            st.subheader("Correlation Map")
            self.create_correlation_heatmap(selected_dataset)
            
    def page_model_results(self):
        """
        Create the Model Results page.
        
        This method generates a page with various visualizations and statistics for
        model results.
        """
        st.title("Results")

        df_results = self.create_results_dataframe()
        all_datasets = list(self.dfs.keys())
        all_algorithms = list(self.results_genetic[all_datasets[0]].keys())
        selected_dataset = st.selectbox("Select the dataset:", all_datasets)
        selected_algorithm = st.selectbox("Select the algorithm", all_algorithms)

        methods = [
            ('Genetic', 'RMSE (Genetic)'),
            ('PSO', 'RMSE (PSO)'),
            ('CDEA', 'RMSE (CDEA)'),
            ('ABC', 'RMSE (ABC)'),
            ('GWO', 'RMSE (GWO)'),
            ('WOA', 'RMSE (WOA)')
        ]

        df_results_filtered = df_results[df_results['Dataset'] == selected_dataset]
        comparison_fig = go.Figure()
        for label, column_name in methods:
            comparison_fig.add_trace(go.Bar(
                x=df_results_filtered['Algorithm'],
                y=df_results_filtered[column_name],
                name=label
            ))

        comparison_fig.update_layout(
            title=f'RMSE Comparison by Optimization Approach ({selected_dataset})',
            xaxis_title='Algorithm',
            yaxis_title='RMSE',
            barmode='group'
        )
        st.plotly_chart(comparison_fig)

        st.subheader(f"Best parameters for {selected_algorithm} ({selected_dataset}):")
        for label, results in [
            ('Genetic', self.results_genetic),
            ('PSO', self.results_pso),
            ('CDEA', self.results_cdea),
            ('ABC', self.results_abc),
            ('GWO', self.results_gwo),
            ('WOA', self.results_woa)
        ]:
            st.markdown(f"**{label} Method:**")
            st.json(results[selected_dataset][selected_algorithm]['best_params'])

        st.subheader("Results Table")
        st.dataframe(df_results)
        
        # Button to export to Excel
        if st.button("Export Results to Excel"):
            with st.spinner("Exporting results..."):
                filename = self.export_results_to_excel()
                
                # Get the best algorithm to display in the message
                _, best_algorithm = self.create_best_hyperparams_dataframe()
                
                st.success("Results exported successfully")
                st.info("Se ha generado un archivo Excel con las hojas:")
                st.markdown(f"""
                - **General Results**: Todos los resultados de los modelos
                - **Best Model - {best_algorithm}**: Hiperparámetros del mejor modelo según RMSE
                - **Top 3 Algorithms**: Los 3 mejores resultados globales
                - **Best By Dataset**: Mejor algoritmo bioinspirado para cada dataset
                """)
                
                if os.path.exists(filename):
                    with open(filename, "rb") as f:
                        st.download_button(
                            label=f"Download {os.path.basename(filename)}",
                            data=f,
                            file_name=os.path.basename(filename),
                            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            key=filename
                        )
                else:
                    st.error(f"File not found: {filename}")

        # Section: Best bioinspired algorithm by selected dataset
        st.markdown("---")
        st.subheader("Mejor algoritmo bioinspirado por dataset")
        df_best_by_dataset = self.create_best_algorithms_by_dataset()
        df_best_for_selected = df_best_by_dataset[df_best_by_dataset['Dataset'] == selected_dataset]

        if df_best_for_selected.empty:
            st.info("No hay resultados disponibles para el dataset seleccionado.")
        else:
            st.markdown(f"**Dataset seleccionado:** {selected_dataset}")
            best_row = df_best_for_selected.sort_values('RMSE').iloc[0]
            st.markdown(
                f"**Mejor combinación bioinspirada:** {best_row['Method']} / {best_row['Algorithm']} "
                f"con RMSE = {best_row['RMSE']:.4f} ({best_row['Training Time (s)']} s)"
            )
            st.dataframe(df_best_for_selected)

            fig_best_dataset = px.bar(
                df_best_for_selected,
                x='Method',
                y='RMSE',
                color='Method',
                text='Algorithm'
            )
            fig_best_dataset.update_layout(
                title=f'Mejor algoritmo bioinspirado para {selected_dataset}',
                yaxis_title='RMSE'
            )
            st.plotly_chart(fig_best_dataset)

        # New professional section: Best dataset per bioinspired optimizer
        st.markdown("---")
        st.subheader("Best dataset por optimizador bioinspirado")

        df_best_datasets = self.create_best_dataset_per_algorithm()
        if df_best_datasets.empty:
            st.info("No hay resultados disponibles para los optimizadores bioinspirados.")
        else:
            # Display table
            st.table(df_best_datasets)

            # Bar chart of RMSE by method for visual emphasis
            fig_best = px.bar(df_best_datasets, x='Method', y='RMSE', color='Method', text='Dataset')
            fig_best.update_layout(title='Mejor dataset por optimizador (RMSE más bajo)', yaxis_title='RMSE')
            st.plotly_chart(fig_best)

            # Allow previewing the dataset selected as best for a method
            method_options = df_best_datasets['Method'].tolist()
            selected_method_preview = st.selectbox('Seleccionar optimizador para ver dataset', method_options)
            preview_row = df_best_datasets[df_best_datasets['Method'] == selected_method_preview].iloc[0]
            preview_dataset_name = preview_row['Dataset']
            preview_algorithm = preview_row['Algorithm']

            st.markdown(f"**Preview del dataset seleccionado:** {preview_dataset_name} — Algoritmo: {preview_algorithm}")
            if preview_dataset_name in self.dfs:
                st.dataframe(self.ensure_arrow_compatible(self.dfs[preview_dataset_name].head(50)))
                # show correlation heatmap for the preview dataset
                self.create_correlation_heatmap(preview_dataset_name)

                # Show the best hyperparameters found for this method/dataset/algorithm
                st.subheader("Mejores hiperparámetros para la combinación seleccionada")
                # Map method label to results dict
                method_map = {
                    'Genetic': self.results_genetic,
                    'PSO': self.results_pso,
                    'CDEA': self.results_cdea,
                    'ABC': self.results_abc,
                    'GWO': self.results_gwo,
                    'WOA': self.results_woa
                }
                selected_results = method_map.get(selected_method_preview)
                if selected_results is not None:
                    st.json(selected_results[preview_dataset_name][preview_algorithm].get('best_params', {}))
            else:
                st.error(f"Dataset no disponible: {preview_dataset_name}")
