# OptimML Framework

Framework para comparación automatizada de modelos de regresión y optimización de hiperparámetros usando algoritmos bioinspirados, con interfaz interactiva para análisis exploratorio y visualización de resultados.

## Descripción general

Este proyecto implementa un flujo completo de machine learning para evaluar múltiples modelos de regresión sobre distintos conjuntos de datos. La aplicación carga datasets CSV, realiza preprocesamiento, divide los datos en entrenamiento y prueba, aplica estrategias de optimización de hiperparámetros basadas en metaheurísticas y genera un dashboard para comparar resultados de rendimiento.

La arquitectura del proyecto está organizada por módulos, donde cada componente se encarga de una etapa específica:

- carga y preparación de datos
- evaluación de algoritmos
- optimización de hiperparámetros
- predicción y análisis de rendimiento
- visualización de resultados en una interfaz Streamlit

## ¿Qué se implementó en este proyecto?

### 1. Carga y procesamiento de datasets
El sistema permite:

- leer múltiples archivos CSV desde la carpeta datasets
- preparar los datos para entrenamiento y validación
- normalizar y convertir tipos para compatibilidad con Arrow/Streamlit
- manejar varios conjuntos de datos en un mismo flujo de análisis

Esto se realiza principalmente en:

- app.py
- components/CMain.py
- components/CVisualizer.py
- components/CGenerator.py

### 2. Optimización de hiperparámetros con algoritmos bioinspirados
El framework incluye varias estrategias de búsqueda para ajustar hiperparámetros de modelos de regresión:

- Genetic Algorithm (GA)
- Particle Swarm Optimization (PSO)
- CDEA
- ABC
- GWO
- WOA

Estas búsquedas se implementan en el módulo de evaluación y comparan el rendimiento de diferentes configuraciones sin necesidad de definir manualmente una grilla fija de parámetros.

### 3. Modelos de regresión soportados
El proyecto evalúa una variedad de modelos, entre ellos:

- LinearRegression
- DecisionTreeRegressor
- RandomForestRegressor
- GradientBoostingRegressor
- Lasso
- Ridge
- ElasticNet
- KNeighborsRegressor
- SVR
- MLPRegressor
- XGBRegressor

### 4. Pipeline de entrenamiento y evaluación
La aplicación ejecuta un flujo completo de:

1. lectura de datasets
2. partición train/test
3. entrenamiento con modelos y optimización de hiperparámetros
4. cálculo de métricas de rendimiento
5. comparación entre métodos de optimización
6. exportación de resultados

Las métricas principales se basan en resultados de regresión, con comparación de calidad y tiempos de ejecución.

### 5. Dashboard interactivo
Se genera una interfaz con Streamlit para visualizar:

- comparación del rendimiento de los modelos
- resultados por dataset
- métricas por algoritmo
- mejores configuraciones encontradas
- exportación de resultados a Excel

El dashboard se construye con la clase Visualizer dentro de components/CVisualizer.py.

### 6. Exportación de resultados
El proyecto incluye la capacidad de exportar tablas y resultados a archivos Excel para análisis posterior. Esta funcionalidad se usa para guardar resumen general, mejores hiperparámetros y ranking de algoritmos.

## Estructura del proyecto

```text
OptimML-Framework/
├── app.py                     # Punto de entrada principal de Streamlit
├── README.md                 # Documentación del proyecto
├── requirements.txt          # Dependencias del proyecto
├── run_app.bat               # Script para ejecutar la app en Windows
├── LICENSE                   # Licencia del proyecto
├── Requerimientos.txt        # Lista extra de requisitos
├── assets/                   # Recursos visuales y estáticos
├── components/
│   ├── __init__.py
│   ├── CMain.py              # Orquestación general del flujo del sistema
│   ├── CGenerator.py         # Generación y preparación de datasets
│   ├── CEvaluator.py         # Optimización de hiperparámetros y evaluación
│   ├── CPredictor.py         # Predicción y análisis de resultados
│   ├── CVisualizer.py        # Dashboard y visualizaciones
│   └── utils/
│       ├── __init__.py
│       └── print_utils.py    # Utilidades de salida formateada en consola
├── datasets/                 # Archivos CSV de entrada
├── results/                  # Resultados generados por la ejecución
├── scripts/                  # Scripts auxiliares para tablas y resultados
└── APPENDIX.md               # Apéndice documental del proyecto
```

## Requisitos

- Python 3.8 o superior
- Dependencias principales:
  - streamlit
  - pandas
  - numpy
  - scikit-learn
  - scikit-learn-genetic
  - xgboost
  - matplotlib
  - seaborn
  - plotly
  - sqlalchemy
  - pymssql

Se pueden instalar todas junto con:

```bash
pip install -r requirements.txt
```

## Instalación

1. Clonar el repositorio:

```bash
git clone <url-del-repositorio>
cd OptimML-Framework
```

2. Crear un entorno virtual (opcional, pero recomendado):

```bash
python -m venv venv
```

En Windows:

```bash
venv\Scripts\activate
```

En Linux/macOS:

```bash
source venv/bin/activate
```

3. Instalar dependencias:

```bash
pip install -r requirements.txt
```

## Ejecución

Para iniciar la aplicación:

```bash
streamlit run app.py
```

También se puede ejecutar desde Windows con:

```bash
run_app.bat
```

Al abrir la app, el sistema ejecuta el flujo de carga, entrenamiento y comparación de modelos automáticamente.

## Flujo de trabajo del sistema

```text
CSV datasets
    ↓
Preprocesamiento
    ↓
Train/Test split
    ↓
Optimización de hiperparámetros (GA, PSO, CDEA, ABC, GWO, WOA)
    ↓
Entrenamiento de modelos
    ↓
Evaluación de rendimiento
    ↓
Dashboard + exportación de resultados
```

## Casos de uso

Este proyecto es útil para:

- comparar algoritmos de regresión en distintos datasets
- analizar el impacto de la optimización de hiperparámetros
- evaluar varias metaheurísticas sobre el mismo problema
- generar una vista visual del comportamiento del modelo
- exportar resultados para reportes o análisis posterior

## Notas relevantes

- El proyecto está orientado a tareas de comparación experimental de modelos.
- La interfaz está diseñada para facilitar la exploración visual de resultados.
- La ejecución se enfoca en datasets tabulares de regresión.
- Los resultados se pueden interpretar a partir de métricas de rendimiento y mejores configuraciones obtenidas por cada estrategia.

## Licencia

Este proyecto se distribuye bajo la licencia MIT. Consulte el archivo LICENSE para más detalles.

## Créditos

Proyecto desarrollado como framework de optimización y comparación de algoritmos de machine learning con enfoque en metaheurísticas y análisis visual de resultados.
