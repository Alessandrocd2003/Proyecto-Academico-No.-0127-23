from openpyxl import load_workbook
import json
p = r"results/framework_results_20260527_105048.xlsx"
wb = load_workbook(p, data_only=True)
ws_general = wb["General Results"]
rows = list(ws_general.iter_rows(values_only=True))
headers = rows[0]
header_index = {h:i for i,h in enumerate(headers)}
approaches = ["Genetic","Exhaustive","PSO","CDEA","ABC"]
def get_for(row, approach):
    if approach=="Genetic":
        rmse = row[header_index["RMSE (Genetic)"]]
        hyp = row[header_index["Hyperparameters (Genetic)"]]
        t = row[header_index["Training Time (Genetic)"]]
    elif approach=="Exhaustive":
        rmse = row[header_index["RMSE (Exhaustive)"]]
        hyp = row[header_index["Hyperparameters (Exhaustive)"]]
        t = row[header_index["Training Time (Exhaustive)"]]
    elif approach=="PSO":
        rmse = row[header_index["RMSE (PSO)"]]
        hyp = row[header_index["Hyperparameters (PSO)"]]
        t = row[header_index["Training Time (PSO)"]]
    elif approach=="CDEA":
        rmse = row[header_index["RMSE (CDEA)"]]
        hyp = row[header_index["Hyperparameters (CDEA)"]]
        t = row[header_index["Training Time (CDEA)"]]
    elif approach=="ABC":
        rmse = row[header_index["RMSE (ABC)"]]
        hyp = row[header_index["Hyperparameters (ABC)"]]
        t = row[header_index["Training Time (ABC)"]]
    else:
        return None
    return rmse, hyp, t
data = {}
for row in rows[1:]:
    ds = row[0]
    alg = row[1]
    key = (ds, alg)
    data[key] = {}
    for app in approaches:
        res = get_for(row, app)
        data[key][app] = res

ws_lasso = wb["Best Model - Lasso"]
lasso_rows = list(ws_lasso.iter_rows(values_only=True))

out_lines = []
out_lines.append("## Table 2: Comparison of Lasso across bioinspired approaches\n")
out_lines.append("| Dataset | Approach | Algorithm | RMSE | Time (s) | alpha | fit_intercept | max_iter | tol | selection |")
out_lines.append("|---------|----------|-----------|------|----------|-------|---------------|----------|-----|-----------|")
for r in lasso_rows[1:]:
    ds, approach, algorithm, rmse, time_s, alpha, fit_intercept, max_iter, tol, selection = r
    if approach in ("Genetic","PSO","CDEA","ABC"):
        out_lines.append(f"| {ds} | {approach} | {algorithm} | {rmse} | {time_s} | {alpha} | {fit_intercept} | {max_iter} | {tol} | {selection} |")

out_lines.append("\n## Table 3: Comparison of Different Algorithms and Bioinspired Approaches\n")
out_lines.append("| Dataset | Approach | Algorithm | RMSE | Time (s) | clf__alpha | clf__fit_intercept | clf__max_iter | clf__tol | clf__selection | clf__colsample_bytree | clf__learning_rate | clf__max_depth | clf__n_estimators | clf__min_samples_split |")
out_lines.append("|---------|----------|-----------|------|----------|------------|-------------------|---------------|----------|----------------|----------------------|-------------------|---------------|------------------|----------------------|")
candidates = [ ("poi-2","Lasso"), ("poi-2","XGBRegressor"), ("tomcat","RandomForestRegressor") ]
import ast
for key in candidates:
    if key in data:
        ds, alg = key
        for app in ("Genetic","PSO","CDEA","ABC"):
            rmse, hyp, t = data[key][app]
            hyp_s = hyp if hyp else ""
            alpha = fit_intercept = max_iter = tol = selection = colsample = lr = maxd = n_est = min_split = "--"
            try:
                d = ast.literal_eval(hyp_s) if hyp_s else {}
                alpha = d.get('clf__alpha','--') if 'clf__alpha' in d else (d.get('alpha','--') if 'alpha' in d else alpha)
                fit_intercept = d.get('clf__fit_intercept', d.get('fit_intercept','--'))
                max_iter = d.get('clf__max_iter', d.get('max_iter','--'))
                tol = d.get('clf__tol', d.get('tol','--'))
                selection = d.get('clf__selection', d.get('selection','--'))
                colsample = d.get('clf__colsample_bytree', d.get('colsample_bytree','--'))
                lr = d.get('clf__learning_rate', d.get('learning_rate','--'))
                maxd = d.get('clf__max_depth', d.get('max_depth','--'))
                n_est = d.get('clf__n_estimators', d.get('n_estimators','--'))
                min_split = d.get('clf__min_samples_split', d.get('min_samples_split','--'))
            except Exception:
                pass
            out_lines.append(f"| {ds} | {app} | {alg} | {rmse} | {t} | {alpha} | {fit_intercept} | {max_iter} | {tol} | {selection} | {colsample} | {lr} | {maxd} | {n_est} | {min_split} |")

out_lines.append("\n## Table 4: Training time comparison among Bioinspired approaches\n")
out_lines.append("| Dataset | Algorithm | Genetic Time (s) | PSO Time (s) | CDEA Time (s) | ABC Time (s) | PSO/Genetic Speedup | CDEA/Genetic Speedup | ABC/Genetic Speedup |")
out_lines.append("|---------|-----------|------------------|--------------|---------------|--------------|--------------------|--------------------|--------------------|")
algs_of_interest = ["LinearRegression","DecisionTreeRegressor","RandomForestRegressor","Lasso","XGBRegressor"]
def tosec(t):
    if not t: return None
    try:
        s = str(t).strip()
        if 'second' in s:
            return float(s.split()[0])
        return float(s)
    except:
        return None
def speedup(base, other):
    try:
        return round(base/other,2)
    except:
        return '--'
for (ds, alg) in list(data.keys()):
    if alg in algs_of_interest:
        g = data[(ds,alg)]['Genetic']
        p = data[(ds,alg)]['PSO']
        c = data[(ds,alg)]['CDEA']
        a = data[(ds,alg)]['ABC']
        gt = tosec(g[2])
        pt = tosec(p[2])
        ct = tosec(c[2])
        at = tosec(a[2])
        sp_p = speedup(gt, pt) if gt and pt else '--'
        sp_c = speedup(gt, ct) if gt and ct else '--'
        sp_a = speedup(gt, at) if gt and at else '--'
        out_lines.append(f"| {ds} | {alg} | {gt if gt is not None else '--'} | {pt if pt is not None else '--'} | {ct if ct is not None else '--'} | {at if at is not None else '--'} | {sp_p} | {sp_c} | {sp_a} |")

out_lines.append("\n## Table 5: RMSE comparison between Bioinspired approaches\n")
out_lines.append("| Dataset | Algorithm | RMSE (Genetic) | RMSE (PSO) | RMSE (CDEA) | RMSE (ABC) | Diff PSO | Diff CDEA | Diff ABC |")
out_lines.append("|---------|-----------|----------------|------------|------------|-----------|----------|----------|---------|")
for (ds, alg), vals in data.items():
    try:
        rg = float(vals['Genetic'][0]) if vals['Genetic'][0] else None
        rp = float(vals['PSO'][0]) if vals['PSO'][0] else None
        rc = float(vals['CDEA'][0]) if vals['CDEA'][0] else None
        ra = float(vals['ABC'][0]) if vals['ABC'][0] else None
        def diff(x,y):
            return round(abs(x-y),6) if x is not None and y is not None else '--'
        out_lines.append(f"| {ds} | {alg} | {rg if rg is not None else '--'} | {rp if rp is not None else '--'} | {rc if rc is not None else '--'} | {ra if ra is not None else '--'} | {diff(rg,rp)} | {diff(rg,rc)} | {diff(rg,ra)} |")
    except Exception:
        pass

with open('scripts/appendix_generated_utf8.md','w',encoding='utf-8') as f:
    f.write('\n'.join(out_lines))

print('WROTE scripts/appendix_generated_utf8.md')
