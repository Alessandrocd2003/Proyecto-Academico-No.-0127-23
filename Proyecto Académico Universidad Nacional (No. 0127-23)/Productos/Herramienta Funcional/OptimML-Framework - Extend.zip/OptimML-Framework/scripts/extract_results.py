from openpyxl import load_workbook
import json
p = r"results/framework_results_20260527_105048.xlsx"
wb = load_workbook(p, read_only=True, data_only=True)
out = {"sheets": []}
for name in wb.sheetnames:
    ws = wb[name]
    rows = []
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        rows.append([str(x) if x is not None else '' for x in row])
        if i>=9:
            break
    out["sheets"].append({"name": name, "preview": rows})
print(json.dumps(out, ensure_ascii=False, indent=2))
