from openpyxl import load_workbook
import json
p = r"results/framework_results_20260527_105048.xlsx"
wb = load_workbook(p, data_only=True)
ws_general = wb["General Results"]
# read all rows
rows = list(ws_general.iter_rows(values_only=True))
headers = rows[0]
# find indices for columns
header_index = {h:i for i,h in enumerate(headers)}
# approaches columns mapping
approaches = ["Genetic","Exhaustive","PSO","CDEA","ABC"]
# helper to extract hyperparams/time per approach from a row

def get_for(row, approach):
    if approach=="Genetic":
        rmse = row[header_index["RMSE (Genetic)"]]
        hyp = row[header_index["Hyperparameters (Genetic)"]]
        t = row[header_index["Training Time (Genetic)"]]
    elif approach=="Exhaustive":
        rmse = row[header_index["RMSE (Exhaustive)"]]
        hyp = row[header_index["Hyperparameters (Exhaustive)"]]
        t = row[header_index["Training Time (Exhaustive)"]]
    elif approach=="PSO":
        rmse = row[header_index["RMSE (PSO)"]]
        hyp = row[header_index["Hyperparameters (PSO)"]]
        t = row[header_index["Training Time (PSO)"]]
    elif approach=="CDEA":
        rmse = row[header_index["RMSE (CDEA)"]]
        hyp = row[header_index["Hyperparameters (CDEA)"]]
        t = row[header_index["Training Time (CDEA)"]]
    elif approach=="ABC":
        rmse = row[header_index["RMSE (ABC)"]]
        hyp = row[header_index["Hyperparameters (ABC)"]]
        t = row[header_index["Training Time (ABC)"]]
    else:
        return None
    return rmse, hyp, t

# build dictionaries by dataset-algorithm
data = {}
for row in rows[1:]:
    ds = row[0]
    alg = row[1]
    key = (ds, alg)
    data[key] = {}
    for app in approaches:
        res = get_for(row, app)
        data[key][app] = res

# Load Best Model - Lasso sheet
ws_lasso = wb["Best Model - Lasso"]
lasso_rows = list(ws_lasso.iter_rows(values_only=True))
# prepare Table 2: Lasso for poi-2 with bioinspired approaches
md_table2 = []
md_table2.append("| Dataset | Approach | Algorithm | RMSE | Time (s) | alpha | fit_intercept | max_iter | tol | selection |")
md_table2.append("|---------|----------|-----------|------|----------|-------|---------------|----------|-----|-----------|")
for r in lasso_rows[1:]:
    ds, approach, algorithm, rmse, time_s, alpha, fit_intercept, max_iter, tol, selection = r
    if approach in ("Genetic","PSO","CDEA","ABC"):
        md_table2.append(f"| {ds} | {approach} | {algorithm} | {rmse} | {time_s} | {alpha} | {fit_intercept} | {max_iter} | {tol} | {selection} |")

# Table 3: pick some representative algorithms per dataset from General Results: use Lasso and XGBRegressor and RandomForest where available
md_table3 = []
md_table3.append("| Dataset | Approach | Algorithm | RMSE | Time (s) | clf__alpha | clf__fit_intercept | clf__max_iter | clf__tol | clf__selection | clf__colsample_bytree | clf__learning_rate | clf__max_depth | clf__n_estimators | clf__min_samples_split |")
md_table3.append("|---------|----------|-----------|------|----------|------------|-------------------|---------------|----------|----------------|----------------------|-------------------|---------------|------------------|----------------------|")
# look for poi-2 Lasso and poi-2 XGBRegressor and tomcat RandomForest in data
candidates = [ ("poi-2","Lasso"), ("poi-2","XGBRegressor"), ("tomcat","RandomForestRegressor") ]
for key in candidates:
    if key in data:
        ds, alg = key
        for app in ("Genetic","PSO","CDEA","ABC"):
            rmse, hyp, t = data[key][app]
            # parse hyp JSON-like if string
            hyp_s = hyp if hyp else ""
            # try to extract specific params
            alpha = fit_intercept = max_iter = tol = selection = colsample = lr = maxd = n_est = min_split = "--"
            try:
                import ast
                d = ast.literal_eval(hyp_s) if hyp_s else {}
                alpha = d.get('clf__alpha','--') if 'clf__alpha' in d else (d.get('alpha','--') if 'alpha' in d else alpha)
                fit_intercept = d.get('clf__fit_intercept', d.get('fit_intercept','--'))
                max_iter = d.get('clf__max_iter', d.get('max_iter','--'))
                tol = d.get('clf__tol', d.get('tol','--'))
                selection = d.get('clf__selection', d.get('selection','--'))
                colsample = d.get('clf__colsample_bytree', d.get('colsample_bytree','--'))
                lr = d.get('clf__learning_rate', d.get('learning_rate','--'))
                maxd = d.get('clf__max_depth', d.get('max_depth','--'))
                n_est = d.get('clf__n_estimators', d.get('n_estimators','--'))
                min_split = d.get('clf__min_samples_split', d.get('min_samples_split','--'))
            except Exception:
                pass
            md_table3.append(f"| {ds} | {app} | {alg} | {rmse} | {t} | {alpha} | {fit_intercept} | {max_iter} | {tol} | {selection} | {colsample} | {lr} | {maxd} | {n_est} | {min_split} |")

# Table 4: Training times for each dataset/algorithm — create rows per dataset/algorithm for bioinspired times and compute relative speedups vs Genetic
md_table4 = []
md_table4.append("| Dataset | Algorithm | Genetic Time (s) | PSO Time (s) | CDEA Time (s) | ABC Time (s) | PSO/Genetic Speedup | CDEA/Genetic Speedup | ABC/Genetic Speedup |")
md_table4.append("|---------|-----------|------------------|--------------|---------------|--------------|--------------------|--------------------|--------------------|")
# iterate data keys and select a few algorithms (LinearRegression, DecisionTreeRegressor, RandomForestRegressor, Lasso, XGBRegressor)
algs_of_interest = ["LinearRegression","DecisionTreeRegressor","RandomForestRegressor","Lasso","XGBRegressor"]
for (ds, alg) in list(data.keys()):
    if alg in algs_of_interest:
        g = data[(ds,alg)]['Genetic']
        p = data[(ds,alg)]['PSO']
        c = data[(ds,alg)]['CDEA']
        a = data[(ds,alg)]['ABC']
        # extract times as seconds float from strings like '0.36 seconds' or '4.05 seconds'
        def tosec(t):
            if not t: return None
            try:
                s = str(t).strip()
                if 'second' in s:
                    return float(s.split()[0])
                return float(s)
            except:
                return None
        gt = tosec(g[2])
        pt = tosec(p[2])
        ct = tosec(c[2])
        at = tosec(a[2])
        def speedup(base, other):
            try:
                return round(base/other,2)
            except:
                return '--'
        sp_p = speedup(gt, pt) if gt and pt else '--'
        sp_c = speedup(gt, ct) if gt and ct else '--'
        sp_a = speedup(gt, at) if gt and at else '--'
        md_table4.append(f"| {ds} | {alg} | {gt if gt is not None else '--'} | {pt if pt is not None else '--'} | {ct if ct is not None else '--'} | {at if at is not None else '--'} | {sp_p} | {sp_c} | {sp_a} |")

# Table 5: RMSE comparison between bioinspired approaches — produce absolute and relative diffs between Genetic and each other bioinspired approach
md_table5 = []
md_table5.append("| Dataset | Algorithm | RMSE (Genetic) | RMSE (PSO) | RMSE (CDEA) | RMSE (ABC) | Diff PSO | Diff CDEA | Diff ABC |")
md_table5.append("|---------|-----------|----------------|------------|------------|-----------|----------|----------|---------|")
for (ds, alg), vals in data.items():
    try:
        rg = float(vals['Genetic'][0]) if vals['Genetic'][0] else None
        rp = float(vals['PSO'][0]) if vals['PSO'][0] else None
        rc = float(vals['CDEA'][0]) if vals['CDEA'][0] else None
        ra = float(vals['ABC'][0]) if vals['ABC'][0] else None
        def diff(x,y):
            return round(abs(x-y),6) if x is not None and y is not None else '--'
        md_table5.append(f"| {ds} | {alg} | {rg if rg is not None else '--'} | {rp if rp is not None else '--'} | {rc if rc is not None else '--'} | {ra if ra is not None else '--'} | {diff(rg,rp)} | {diff(rg,rc)} | {diff(rg,ra)} |")
    except Exception:
        pass

# print all markdown sections
print("## Table 2: Comparison of Lasso across bioinspired approaches\n")
print('\n'.join(md_table2))
print('\n\n## Table 3: Comparison of Different Algorithms and Bioinspired Approaches\n')
print('\n'.join(md_table3))
print('\n\n## Table 4: Training time comparison among Bioinspired approaches\n')
print('\n'.join(md_table4))
print('\n\n## Table 5: RMSE comparison between Bioinspired approaches\n')
print('\n'.join(md_table5))
