@echo off
title OptimML Framework - Environment Setup

echo ================================================
echo     OptimML Framework - Environment Setup
echo ================================================
echo.
echo This script will set up the R environment for the OptimML Framework.
echo This may take several minutes depending on your internet connection.
echo.

echo Checking R installation...
RScript.exe --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo ERROR: R is not installed or not in PATH.
    echo Please install R from https://cran.r-project.org/
    echo and make sure it's added to your system PATH.
    pause
    exit /b 1
)

echo R is installed. Running environment setup...
echo.

RScript.exe setup_environment.R

if %ERRORLEVEL% neq 0 (
    echo.
    echo ERROR: Environment setup failed.
    echo Please check the output above for error details.
    pause
    exit /b 1
)

echo.
echo ================================================
echo     Environment setup completed successfully!
echo ================================================
echo.
echo You can now run the application using:
echo   - run_app.bat (Windows)
echo   - Rscript -e "shiny::runApp('app.R')" (Command line)
echo.
pause