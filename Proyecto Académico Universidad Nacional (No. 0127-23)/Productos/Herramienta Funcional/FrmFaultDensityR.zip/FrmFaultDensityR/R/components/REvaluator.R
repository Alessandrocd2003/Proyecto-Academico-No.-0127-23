# Model Evaluation && Hyperparameter Optimization Module for OptimML Framework in R
# This module supports both genetic algorithms && exhaustive grid search with parallel processing

library(R6)
library(parallel)
library(doParallel)
library(foreach)
library(caret)
library(randomForest)
library(glmnet)
library(xgboost)
library(FNN)
library(rpart)
library(GA)
# Juan De Dios

# ---- RF sequential flag helpers (non-intrusive) ----
rf_is_forced_sequential <- function() {
  val <- getOption("rf_force_sequential", NA)
  if (is.na(val)) {
    env <- Sys.getenv("RF_FORCE_SEQUENTIAL", unset = "")
    if (nzchar(env)) {
      tolower(env) %in% c("1","true","yes","on")
    } else {
      TRUE  # default safe behavior
    }
  } else {
    isTRUE(val)
  }
}

safe_make_cluster <- function(ncores = NULL) {
  n <- tryCatch({
    d <- parallel::detectCores(logical = TRUE)
    if (is.null(ncores)) d - 1L else min(max(1L, as.integer(ncores)), max(1L, d - 1L))
  }, error = function(e) 1L)
  n <- max(1L, n)
  cl <- parallel::makeCluster(n, type = "PSOCK")
  doParallel::registerDoParallel(cl)
  cl
}

safe_stop_cluster <- function(cl) {
  if (!is.null(cl)) {
    try(parallel::stopCluster(cl), silent = TRUE)
    doParallel::registerDoSEQ()
  }
}

# ---- RandomForest parameter sanitizer (prevents C-level crashes) ----
sanitize_rf_params <- function(params, p, n, is_classification) {
  # p: num features, n: num rows
  safe <- list()
  # ntree
  nt <- suppressWarnings(as.integer(params$ntree %||% 100L))
  if (!is.finite(nt) || nt < 1L) nt <- 100L
  safe$ntree <- nt
  # mtry in [1, p]
  mt <- suppressWarnings(as.integer(params$mtry %||% max(1L, floor(sqrt(p)))))
  if (!is.finite(mt) || mt < 1L) mt <- max(1L, floor(sqrt(p)))
  if (mt > p) mt <- p
  safe$mtry <- mt
  # nodesize >=1 (regression default 5, classification 1)
  ns_def <- if (is_classification) 1L else 5L
  ns <- suppressWarnings(as.integer(params$nodesize %||% ns_def))
  if (!is.finite(ns) || ns < 1L) ns <- ns_def
  safe$nodesize <- ns
  # maxnodes: >= 2 && reasonable upper bound
  mx <- params$maxnodes
  if (is.null(mx) || is.na(mx)) {
    # let RF decide
  } else {
    mx <- suppressWarnings(as.integer(mx))
    if (!is.finite(mx) || mx < 2L) {
      mx <- NULL
    } else {
      # Cap to avoid overflow: at most n (|| n/2 for safety)
      if (mx > max(2L, n)) mx <- max(2L, n)
    }
  }
  safe$maxnodes <- mx
  # sampsize should not exceed n
  if (!is.null(params$sampsize)) {
    ss <- suppressWarnings(as.integer(params$sampsize))
    if (!is.finite(ss) || ss < 1L) ss <- NULL
    else if (ss > n) ss <- n
    safe$sampsize <- ss
  }
  safe
}
# ---------------------------------------------------------------------


# ----------------------------------------------------
source("components/utils/print_utils.R", encoding = "UTF-8")

# ModelEvaluator R6 Class
ModelEvaluator <- R6::R6Class("ModelEvaluator",
  private = list(
    .X_train = NULL,
    .X_test = NULL,
    .y_train = NULL,
    .y_test = NULL,
    .models = list(),
    .param_grids_genetic = list(),
    .param_grids_exhaustive = list()
  ),

  public = list(
    # Initialize the ModelEvaluator
    initialize = function(X_train, X_test, y_train, y_test) {
      private$.X_train <- X_train
      private$.X_test <- X_test
      private$.y_train <- y_train
      private$.y_test <- y_test

      # Initialize parameter grids
      self$initialize_param_grids()

      print_info("ModelEvaluator initialized")
      print_info(paste("Training set size:", nrow(X_train), "x", ncol(X_train)))
      print_info(paste("Test set size:", nrow(X_test), "x", ncol(X_test)))
    },

    # Initialize parameter grids for different algorithms
    initialize_param_grids = function() {
      # Genetic algorithm parameter spaces
      private$.param_grids_genetic <- list(
        LinearRegression = list(),  # No hyperparameters for linear regression

        DecisionTree = list(
          cp = c(0.001, 0.01, 0.1),
          maxdepth = c(3, 5, 7, 10),
          minsplit = c(2, 5, 10),
          minbucket = c(1, 2, 4)
        ),

        RandomForest = list(
          ntree = c(50, 100, 200),
          mtry = c(2, 4, 6),
          maxnodes = c(10, 20, 30),
          nodesize = c(1, 3, 5)
        ),

        Lasso = list(
          alpha = c(1.0),  # Lasso is alpha = 1
          lambda = c(0.001, 0.01, 0.1, 1.0)
        ),

        Ridge = list(
          alpha = c(0.0),  # Ridge is alpha = 0
          lambda = c(0.001, 0.01, 0.1, 1.0)
        ),

        KNN = list(
          k = c(3, 5, 7, 9, 11),
          algorithm = c("kd_tree", "cover_tree", "brute")
        ),

        XGBoost = list(
          nrounds = c(50, 100, 200),
          max_depth = c(3, 5, 7),
          eta = c(0.01, 0.1, 0.3),
          subsample = c(0.8, 1.0),
          colsample_bytree = c(0.8, 1.0)
        )
      )

      # Exhaustive search parameter spaces (smaller ranges for computational efficiency)
      private$.param_grids_exhaustive <- list(
        LinearRegression = list(),  # No hyperparameters for linear regression

        DecisionTree = list(
          cp = c(0.01, 0.1),
          maxdepth = c(5, 10),
          minsplit = c(2, 10),
          minbucket = c(1, 4)
        ),

        RandomForest = list(
          ntree = c(50, 100),
          mtry = c(2, 4),
          maxnodes = c(10, 20),
          nodesize = c(1, 5)
        ),

        Lasso = list(
          alpha = c(1.0),
          lambda = c(0.01, 0.1, 1.0)
        ),

        Ridge = list(
          alpha = c(0.0),
          lambda = c(0.01, 0.1, 1.0)
        ),

        KNN = list(
          k = c(3, 5, 7),
          algorithm = c("kd_tree", "brute")
        ),

        XGBoost = list(
          nrounds = c(50, 100),
          max_depth = c(3, 5),
          eta = c(0.01, 0.1),
          subsample = c(0.8, 1.0),
          colsample_bytree = c(0.8, 1.0)
        )
      )
    },

    # Genetic algorithm search with parallel processing
    genetic_search = function(algorithm, settings) {
      print_subsection_header("Genetic Algorithm Hyperparameter Optimization")
      print_model_training_start(algorithm, "genetic")

      start_time <- Sys.time()

      # Get parameter grid for the algorithm
      param_grid <- private$.param_grids_genetic[[algorithm]]

      if (length(param_grid) == 0) {
        # No hyperparameters to optimize (e.g., Linear Regression)
        model <- self$train_single_model(algorithm, list())
        training_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))

        return(list(
          model = model,
          best_params = list(),
          training_time = training_time
        ))
      }

      # Define fitness function for genetic algorithm
      fitness_function <- function(params) {
        tryCatch({
          # Convert parameter vector to named list
          param_list <- self$vector_to_params(params, param_grid)

          # Train model with these parameters
          model <- self$train_single_model(algorithm, param_list)

          # Make predictions
          predictions <- self$predict_model(model, algorithm, private$.X_test)

          # Calculate RMSE (we want to minimize this, so return negative)
          rmse <- sqrt(mean((private$.y_test - predictions)^2))
          return(-rmse)  # Negative because GA maximizes

        }, error = function(e) {
          return(-1000)  # Return very poor fitness for invalid parameters
        })
      }

      # Set up parameter bounds for GA
      param_bounds <- self$get_param_bounds(param_grid)

      # Run genetic algorithm with parallel processing and specified operators
      # Calculate elitism based on settings (default to 5% if not specified)
      elitism_count <- if (is.null(settings$ga_elitism_count)) {
        max(1, round(settings$ga_population * 0.05))
      } else {
        settings$ga_elitism_count
      }
      
      # Get mutation and crossover rates
      pmutation <- if (is.null(settings$ga_mutation_rate)) 0.1 else settings$ga_mutation_rate
      pcrossover <- if (is.null(settings$ga_crossover_rate)) 0.8 else settings$ga_crossover_rate
      
      print(paste("GA Configuration:"))
      print(paste("  Population Size:", settings$ga_population))
      print(paste("  Max Iterations:", settings$ga_generations))
      print(paste("  Crossover Rate:", pcrossover))
      print(paste("  Mutation Rate:", pmutation))
      print(paste("  Elitism Count:", elitism_count))
      
      # Get number of runs (default to 1 if not specified)
      num_runs <- if (is.null(settings$ga_runs)) 1 else settings$ga_runs
      print(paste("  Number of runs:", num_runs))
      
      # Run GA multiple times and keep the best result
      best_ga_result <- NULL
      best_fitness <- -Inf
      
      for (run in 1:num_runs) {
        print(paste("Running GA iteration", run, "of", num_runs))
        
        # Use different seed for each run
        current_seed <- 42 + run
        
        if (settings$use_parallel && !(identical(algorithm, "RandomForest") && rf_is_forced_sequential())) {
          # Parallel GA with specified operators
          ga_result <- GA::ga(
            type = "real-valued",
            fitness = fitness_function,
            lower = param_bounds$lower,
            upper = param_bounds$upper,
            popSize = settings$ga_population,
            maxiter = settings$ga_generations,
            pcrossover = pcrossover,
            pmutation = pmutation,
            crossover = gareal_blxCrossover,
            mutation = gareal_raMutation,
            elitism = elitism_count,
            parallel = if (identical(algorithm, "RandomForest") && rf_is_forced_sequential()) FALSE else TRUE,
            monitor = FALSE,
            seed = current_seed
          )
        } else {
          # Sequential GA with specified operators
          ga_result <- GA::ga(
            type = "real-valued",
            fitness = fitness_function,
            lower = param_bounds$lower,
            upper = param_bounds$upper,
            popSize = settings$ga_population,
            maxiter = settings$ga_generations,
            pcrossover = pcrossover,
            pmutation = pmutation,
            crossover = gareal_blxCrossover,
            mutation = gareal_raMutation,
            elitism = elitism_count,
            monitor = FALSE,
            seed = current_seed
          )
        }
        
        # Check if this is the best result so far
        if (ga_result@fitnessValue > best_fitness) {
          best_fitness <- ga_result@fitnessValue
          best_ga_result <- ga_result
          print(paste("New best fitness found in run", run, ":", best_fitness))
        }
      }
      
      print(paste("Best fitness across all runs:", best_fitness))

      # Get best parameters from the best run
      best_params <- self$vector_to_params(best_ga_result@solution[1, ], param_grid)

      # Train final model with best parameters
      best_model <- self$train_single_model(algorithm, best_params)

      training_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))

      print_model_training_complete(algorithm, "genetic", training_time,
                                   list(fitness = best_ga_result@fitnessValue, runs = num_runs))

      return(list(
        model = best_model,
        best_params = best_params,
        training_time = training_time
      ))
    },

    # Exhaustive search with parallel processing
    exhaustive_search = function(algorithm, settings) {
      print_subsection_header("Exhaustive Grid Search Hyperparameter Optimization")
      print_model_training_start(algorithm, "exhaustive")

      start_time <- Sys.time()

      # Get parameter grid for the algorithm
      param_grid <- private$.param_grids_exhaustive[[algorithm]]

      if (length(param_grid) == 0) {
        # No hyperparameters to optimize
        model <- self$train_single_model(algorithm, list())
        training_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))

        return(list(
          model = model,
          best_params = list(),
          training_time = training_time
        ))
      }

      # Generate all parameter combinations
      param_combinations <- expand.grid(param_grid, stringsAsFactors = FALSE)

      print_info(paste("Testing", nrow(param_combinations), "parameter combinations"))

      # Parallel evaluation of parameter combinations
      if (settings$use_parallel && !(identical(algorithm, "RandomForest") && rf_is_forced_sequential())) {
        results <- foreach(i = 1:nrow(param_combinations), .combine = rbind,
                          .packages = c("randomForest", "glmnet", "xgboost", "FNN", "rpart")) %dopar% {

          param_list <- as.list(param_combinations[i, ])

          tryCatch({
            # Train model with these parameters
            model <- self$train_single_model(algorithm, param_list)

            # Make predictions
            predictions <- self$predict_model(model, algorithm, private$.X_test)

            # Calculate RMSE
            rmse <- sqrt(mean((private$.y_test - predictions)^2))

            data.frame(index = i, rmse = rmse, stringsAsFactors = FALSE)

          }, error = function(e) {
            data.frame(index = i, rmse = 1000, stringsAsFactors = FALSE)  # High RMSE for errors
          })
        }
      } else {
        # Sequential evaluation
        results <- data.frame(index = integer(), rmse = numeric(), stringsAsFactors = FALSE)

        for (i in 1:nrow(param_combinations)) {
          param_list <- as.list(param_combinations[i, ])

          tryCatch({
            model <- self$train_single_model(algorithm, param_list)
            predictions <- self$predict_model(model, algorithm, private$.X_test)
            rmse <- sqrt(mean((private$.y_test - predictions)^2))

            results <- rbind(results, data.frame(index = i, rmse = rmse, stringsAsFactors = FALSE))

          }, error = function(e) {
            results <- rbind(results, data.frame(index = i, rmse = 1000, stringsAsFactors = FALSE))
          })
        }
      }

      # Find best parameters
      best_index <- which.min(results$rmse)
      best_params <- as.list(param_combinations[best_index, ])
      best_rmse <- results$rmse[best_index]

      # Train final model with best parameters
      best_model <- self$train_single_model(algorithm, best_params)

      training_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))

      print_model_training_complete(algorithm, "exhaustive", training_time,
                                   list(best_rmse = best_rmse))

      return(list(
        model = best_model,
        best_params = best_params,
        training_time = training_time
      ))
    },

    # Train a single model with given parameters
    train_single_model = function(algorithm, params) {
      switch(algorithm,
             "LinearRegression" = {
               # Construimos el data.frame de entrenamiento con la columna objetivo 'y'
               train_df <- data.frame(as.data.frame(private$.X_train), y = private$.y_train, check.names = FALSE)
               stats::lm(y ~ ., data = train_df)
             },

             "DecisionTree" = {
               control <- rpart::rpart.control(
                 cp = params$cp %||% 0.01,
                 maxdepth = params$maxdepth %||% 10,
                 minsplit = params$minsplit %||% 2,
                 minbucket = params$minbucket %||% 1
               )
               train_df <- data.frame(as.data.frame(private$.X_train), y = private$.y_train, check.names = FALSE)
               rpart::rpart(y ~ ., data = train_df, control = control)
             },

             "RandomForest" = {
               # Sanitize parameters to avoid internal C-level errors
is_class <- is.factor(private$.y_train)
rf_params <- sanitize_rf_params(params, p = ncol(private$.X_train), n = nrow(private$.X_train), is_classification = is_class)

args <- list(
  x = private$.X_train,
  y = private$.y_train,
  ntree = rf_params$ntree,
  mtry = rf_params$mtry,
  nodesize = rf_params$nodesize
)
if (!is.null(rf_params$maxnodes)) args$maxnodes <- rf_params$maxnodes
if (!is.null(rf_params$sampsize)) args$sampsize <- rf_params$sampsize

# Guard against single-class factor
if (is_class && length(unique(private$.y_train)) < 2L) {
  stop("RandomForest: y_train tiene una sola clase; no puede entrenar.")
}

# Train with tryCatch; if 'matrix\\(integer\\(nrnodes\\)\\)' appears, relax maxnodes
rf_model <- tryCatch({
  do.call(randomForest::randomForest, args)
}, warning = function(w) {
  if (grepl("matrix\\(integer\\(nrnodes\\)\\)", conditionMessage(w), fixed = TRUE)) {
    args$maxnodes <- NULL
    do.call(randomForest::randomForest, args)
  } else { suppressWarnings(do.call(randomForest::randomForest, args)) }
}, error = function(e) {
  # Last resort: drop maxnodes && clamp mtry to sqrt(p)
  args$maxnodes <- NULL
  args$mtry <- max(1L, floor(sqrt(ncol(private$.X_train))))
  do.call(randomForest::randomForest, args)
})
rf_model
             },

             "Lasso" = {
               glmnet::glmnet(
                 x = as.matrix(private$.X_train),
                 y = private$.y_train,
                 alpha = 1.0,  # Lasso
                 lambda = params$lambda %||% 0.1
               )
             },

             "Ridge" = {
               glmnet::glmnet(
                 x = as.matrix(private$.X_train),
                 y = private$.y_train,
                 alpha = 0.0,  # Ridge
                 lambda = params$lambda %||% 0.1
               )
             },

             "KNN" = {
               # KNN no entrena un modelo paramétrico; guardamos parámetros y datos
               list(
                 X_train = private$.X_train,
                 y_train = private$.y_train,
                 k = params$k %||% 5,
                 algorithm = params$algorithm %||% "kd_tree"
               )
             },

             "XGBoost" = {
               # ensure integer max_depth for XGBoost
                if (!is.null(params$max_depth)) {
                  params$max_depth <- as.integer(round(params$max_depth))
                }
                xgboost::xgboost(
                 data = as.matrix(private$.X_train),
                 label = private$.y_train,
                 nrounds = params$nrounds %||% 100,
                 max_depth = params$max_depth %||% 6,
                 eta = params$eta %||% 0.3,
                 subsample = params$subsample %||% 1.0,
                 colsample_bytree = params$colsample_bytree %||% 1.0,
                 verbose = 0
               )
             },


        stop(paste("Unknown algorithm:", algorithm))
      )
    },

    # Make predictions with a trained model
    predict_model = function(model, algorithm, X_test) {
      switch(algorithm,
        "LinearRegression" = {
          predict(model, newdata = data.frame(X_test))
        },

        "DecisionTree" = {
          predict(model, newdata = data.frame(X_test))
        },

        "RandomForest" = {
          predict(model, newdata = X_test)
        },

        "Lasso" = ,
        "Ridge" = {
          predict(model, newx = as.matrix(X_test))
        },

        "KNN" = {
          FNN::knn.reg(
            train = model$X_train,
            test = X_test,
            y = model$y_train,
            k = model$k
          )$pred
        },

        "XGBoost" = {
          predict(model, as.matrix(X_test))
        },

        stop(paste("Unknown algorithm:", algorithm))
      )
    },

    # Convert parameter vector to named list for genetic algorithm
    vector_to_params = function(param_vector, param_grid) {
      param_list <- list()
      param_names <- names(param_grid)

      for (i in seq_along(param_names)) {
        param_name <- param_names[i]
        param_values <- param_grid[[param_name]]

        if (is.numeric(param_values)) {
          # Continuous parameter
          min_val <- min(param_values)
          max_val <- max(param_values)
          param_list[[param_name]] <- min_val + param_vector[i] * (max_val - min_val)
        } else {
          # Discrete parameter
          index <- max(1, min(length(param_values), round(param_vector[i] * length(param_values))))
          param_list[[param_name]] <- param_values[index]
        }
      }

      return(param_list)
    },

    # Get parameter bounds for genetic algorithm
    get_param_bounds = function(param_grid) {
      n_params <- length(param_grid)
      lower <- rep(0, n_params)
      upper <- rep(1, n_params)  # We'll scale parameters between 0 && 1

      return(list(lower = lower, upper = upper))
    }
  )
)

# Define %||% operator for default values
`%||%` <- function(x, y) if (is.null(x)) y else x