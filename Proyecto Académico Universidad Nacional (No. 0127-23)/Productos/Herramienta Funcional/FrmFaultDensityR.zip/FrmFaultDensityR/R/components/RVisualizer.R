# Data Visualization and Dashboard Module for OptimML Framework in R
# This module provides Shiny-based interactive visualizations

library(R6)
library(shiny)
library(plotly)
library(DT)
library(corrplot)
library(openxlsx)

source("components/utils/print_utils.R", encoding = "UTF-8")

# Visualizer R6 Class
Visualizer <- R6::R6Class("Visualizer",
  private = list(
    .results_genetic = NULL,
    .results_exhaustive = NULL,
    .datasets = NULL
  ),
  
  public = list(
    # Initialize the Visualizer
    initialize = function(results_genetic, results_exhaustive, datasets) {
      private$.results_genetic <- results_genetic
      private$.results_exhaustive <- results_exhaustive
      private$.datasets <- datasets
      
      print_info("Visualizer initialized")
      print_info(paste("Number of datasets:", length(datasets)))
    },
    
    # Create summary DataFrame for results
    create_results_dataframe = function() {
      if (is.null(private$.results_genetic) || is.null(private$.results_exhaustive)) {
        return(data.frame())
      }
      
      # Create a comparison dataframe
      results_df <- data.frame(
        Method = c("Genetic Algorithm", "Exhaustive Search"),
        RMSE = c(
          private$.results_genetic$rmse %||% NA,
          private$.results_exhaustive$rmse %||% NA
        ),
        R2_Score = c(
          private$.results_genetic$r2 %||% NA,
          private$.results_exhaustive$r2 %||% NA
        ),
        Training_Time_s = c(
          private$.results_genetic$training_time %||% NA,
          private$.results_exhaustive$training_time %||% NA
        ),
        stringsAsFactors = FALSE
      )
      
      return(results_df)
    },
    
    # Create detailed results DataFrame for Excel export
    create_detailed_results_dataframe = function() {
      if (is.null(private$.results_genetic) || is.null(private$.results_exhaustive)) {
        return(data.frame())
      }
      
      detailed_df <- data.frame(
        Method = c("Genetic Algorithm", "Exhaustive Search"),
        RMSE = c(
          private$.results_genetic$rmse %||% NA,
          private$.results_exhaustive$rmse %||% NA
        ),
        MSE = c(
          private$.results_genetic$mse %||% NA,
          private$.results_exhaustive$mse %||% NA
        ),
        MAE = c(
          private$.results_genetic$mae %||% NA,
          private$.results_exhaustive$mae %||% NA
        ),
        R2_Score = c(
          private$.results_genetic$r2 %||% NA,
          private$.results_exhaustive$r2 %||% NA
        ),
        Training_Time_s = c(
          private$.results_genetic$training_time %||% NA,
          private$.results_exhaustive$training_time %||% NA
        ),
        Prediction_Time_s = c(
          private$.results_genetic$prediction_time %||% NA,
          private$.results_exhaustive$prediction_time %||% NA
        ),
        Best_Parameters = c(
          paste(names(private$.results_genetic$best_params), private$.results_genetic$best_params, 
                sep = "=", collapse = "; "),
          paste(names(private$.results_exhaustive$best_params), private$.results_exhaustive$best_params, 
                sep = "=", collapse = "; ")
        ),
        stringsAsFactors = FALSE
      )
      
      return(detailed_df)
    },
    
    # Create correlation heatmap for a dataset
    create_correlation_heatmap = function(dataset_name) {
      if (!dataset_name %in% names(private$.datasets)) {
        return(NULL)
      }
      
      data <- private$.datasets[[dataset_name]]
      numeric_data <- data[sapply(data, is.numeric)]
      
      if (ncol(numeric_data) < 2) {
        return(NULL)
      }
      
      # Calculate correlation matrix
      corr_matrix <- cor(numeric_data, use = "complete.obs")
      
      # Create plotly heatmap
      heatmap_plot <- plot_ly(
        z = ~corr_matrix,
        type = "heatmap",
        colorscale = "RdBu",
        zmin = -1,
        zmax = 1,
        showscale = TRUE,
        hovertemplate = "Row: %{y}<br>Column: %{x}<br>Correlation: %{z:.3f}<extra></extra>"
      ) %>%
        layout(
          title = paste("Correlation Heatmap -", dataset_name),
          xaxis = list(title = "Features", tickangle = 45),
          yaxis = list(title = "Features")
        )
      
      return(heatmap_plot)
    },
    
    # Create histogram plot for a dataset
    create_histogram_plot = function(dataset_name, column_name = NULL) {
      if (!dataset_name %in% names(private$.datasets)) {
        return(NULL)
      }
      
      data <- private$.datasets[[dataset_name]]
      
      if (is.null(column_name)) {
        # Use the first numeric column
        numeric_cols <- names(data)[sapply(data, is.numeric)]
        if (length(numeric_cols) == 0) {
          return(NULL)
        }
        column_name <- numeric_cols[1]
      }
      
      if (!column_name %in% names(data)) {
        return(NULL)
      }
      
      # Create histogram
      hist_plot <- plot_ly(
        x = ~data[[column_name]],
        type = "histogram",
        name = column_name
      ) %>%
        layout(
          title = paste("Distribution of", column_name, "in", dataset_name),
          xaxis = list(title = column_name),
          yaxis = list(title = "Frequency")
        )
      
      return(hist_plot)
    },
    
    # Create box plot for a dataset
    create_boxplot = function(dataset_name, column_name = "defects") {
      if (!dataset_name %in% names(private$.datasets)) {
        return(NULL)
      }
      
      data <- private$.datasets[[dataset_name]]
      
      if (!column_name %in% names(data)) {
        return(NULL)
      }
      
      # Create box plot
      box_plot <- plot_ly(
        y = ~data[[column_name]],
        type = "box",
        name = column_name
      ) %>%
        layout(
          title = paste("Distribution of", column_name, "in", dataset_name),
          yaxis = list(title = column_name)
        )
      
      return(box_plot)
    },
    
    # Create RMSE comparison plot
    create_rmse_comparison_plot = function() {
      if (is.null(private$.results_genetic) || is.null(private$.results_exhaustive)) {
        return(NULL)
      }
      
      genetic_rmse <- private$.results_genetic$rmse %||% NA
      exhaustive_rmse <- private$.results_exhaustive$rmse %||% NA
      
      comparison_plot <- plot_ly() %>%
        add_bars(
          x = c("Genetic Algorithm", "Exhaustive Search"),
          y = c(genetic_rmse, exhaustive_rmse),
          name = "RMSE",
          marker = list(color = c("blue", "red"))
        ) %>%
        layout(
          title = "RMSE Comparison: Genetic vs Exhaustive Search",
          xaxis = list(title = "Method"),
          yaxis = list(title = "RMSE"),
          showlegend = FALSE
        )
      
      return(comparison_plot)
    },
    
    # Create training time comparison plot
    create_training_time_plot = function() {
      if (is.null(private$.results_genetic) || is.null(private$.results_exhaustive)) {
        return(NULL)
      }
      
      genetic_time <- private$.results_genetic$training_time %||% NA
      exhaustive_time <- private$.results_exhaustive$training_time %||% NA
      
      time_plot <- plot_ly() %>%
        add_bars(
          x = c("Genetic Algorithm", "Exhaustive Search"),
          y = c(genetic_time, exhaustive_time),
          name = "Training Time",
          marker = list(color = c("green", "orange"))
        ) %>%
        layout(
          title = "Training Time Comparison",
          xaxis = list(title = "Method"),
          yaxis = list(title = "Time (seconds)"),
          showlegend = FALSE
        )
      
      return(time_plot)
    },
    
    # Export results to Excel
    export_results_to_excel = function(filename = NULL) {
      if (is.null(filename)) {
        timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S")
        filename <- paste0("framework_results_", timestamp, ".xlsx")
      }
      
      # Create results directory if it doesn't exist
      results_dir <- file.path(getwd(), "results")
      if (!dir.exists(results_dir)) {
        dir.create(results_dir, recursive = TRUE)
      }
      
      filepath <- file.path(results_dir, filename)
      
      # Create workbook
      wb <- createWorkbook()
      
      # General results sheet
      general_results <- self$create_results_dataframe()
      addWorksheet(wb, "General Results")
      writeData(wb, "General Results", general_results)
      
      # Detailed results sheet
      detailed_results <- self$create_detailed_results_dataframe()
      addWorksheet(wb, "Detailed Results")
      writeData(wb, "Detailed Results", detailed_results)
      
      # Best parameters sheet
      if (!is.null(private$.results_genetic) && !is.null(private$.results_exhaustive)) {
        # Determine which method performed better
        genetic_rmse <- private$.results_genetic$rmse %||% Inf
        exhaustive_rmse <- private$.results_exhaustive$rmse %||% Inf
        
        if (genetic_rmse <= exhaustive_rmse) {
          best_method <- "Genetic Algorithm"
          best_params <- private$.results_genetic$best_params
          best_rmse <- genetic_rmse
        } else {
          best_method <- "Exhaustive Search" 
          best_params <- private$.results_exhaustive$best_params
          best_rmse <- exhaustive_rmse
        }
        
        best_params_df <- data.frame(
          Method = best_method,
          RMSE = best_rmse,
          Parameter = names(best_params),
          Value = unlist(best_params),
          stringsAsFactors = FALSE
        )
        
        addWorksheet(wb, "Best Model Parameters")
        writeData(wb, "Best Model Parameters", best_params_df)
      }
      
      # Save workbook
      tryCatch({
        saveWorkbook(wb, filepath, overwrite = TRUE)
        print_success(paste("Results exported to:", filepath))
        return(filepath)
      }, error = function(e) {
        print_error(paste("Failed to export results:", e$message))
        return(NULL)
      })
    },
    
    # Get dataset summary statistics
    get_dataset_summary = function(dataset_name) {
      if (!dataset_name %in% names(private$.datasets)) {
        return(NULL)
      }
      
      data <- private$.datasets[[dataset_name]]
      
      summary_stats <- list(
        n_rows = nrow(data),
        n_cols = ncol(data),
        n_numeric_cols = sum(sapply(data, is.numeric)),
        n_missing = sum(is.na(data)),
        missing_percentage = round(sum(is.na(data)) / (nrow(data) * ncol(data)) * 100, 2)
      )
      
      if ("defects" %in% names(data)) {
        summary_stats$target_mean <- mean(data$defects, na.rm = TRUE)
        summary_stats$target_sd <- sd(data$defects, na.rm = TRUE)
        summary_stats$target_min <- min(data$defects, na.rm = TRUE)
        summary_stats$target_max <- max(data$defects, na.rm = TRUE)
      }
      
      return(summary_stats)
    },
    
    # Create missing values summary
    create_missing_values_summary = function(dataset_name) {
      if (!dataset_name %in% names(private$.datasets)) {
        return(data.frame())
      }
      
      data <- private$.datasets[[dataset_name]]
      
      missing_df <- data.frame(
        Column = names(data),
        Missing_Count = sapply(data, function(x) sum(is.na(x))),
        Missing_Percentage = sapply(data, function(x) round(sum(is.na(x))/length(x) * 100, 2)),
        Data_Type = sapply(data, function(x) class(x)[1]),
        stringsAsFactors = FALSE
      )
      
      # Sort by missing count (descending)
      missing_df <- missing_df[order(missing_df$Missing_Count, decreasing = TRUE), ]
      
      return(missing_df)
    },
    
    # Generate model performance report
    generate_performance_report = function() {
      if (is.null(private$.results_genetic) || is.null(private$.results_exhaustive)) {
        return("No results available for report generation.")
      }
      
      genetic_rmse <- private$.results_genetic$rmse %||% NA
      exhaustive_rmse <- private$.results_exhaustive$rmse %||% NA
      genetic_time <- private$.results_genetic$training_time %||% NA
      exhaustive_time <- private$.results_exhaustive$training_time %||% NA
      
      # Determine best method
      best_method <- if (!is.na(genetic_rmse) && !is.na(exhaustive_rmse)) {
        if (genetic_rmse <= exhaustive_rmse) "Genetic Algorithm" else "Exhaustive Search"
      } else {
        "Unable to determine"
      }
      
      # Create report
      report_lines <- c(
        "# OptimML Framework Performance Report",
        "",
        paste("**Report Generated:** ", Sys.time()),
        "",
        "## Model Performance Comparison",
        "",
        "### Genetic Algorithm Results:",
        paste("- RMSE:", sprintf("%.4f", genetic_rmse)),
        paste("- R² Score:", sprintf("%.4f", private$.results_genetic$r2 %||% NA)),
        paste("- Training Time:", sprintf("%.2f seconds", genetic_time)),
        "",
        "### Exhaustive Search Results:",
        paste("- RMSE:", sprintf("%.4f", exhaustive_rmse)),
        paste("- R² Score:", sprintf("%.4f", private$.results_exhaustive$r2 %||% NA)),
        paste("- Training Time:", sprintf("%.2f seconds", exhaustive_time)),
        "",
        paste("## Best Performing Method: **", best_method, "**"),
        ""
      )
      
      if (best_method == "Genetic Algorithm" && !is.null(private$.results_genetic$best_params)) {
        report_lines <- c(report_lines,
          "### Best Parameters (Genetic Algorithm):",
          paste("-", names(private$.results_genetic$best_params), ":", 
                private$.results_genetic$best_params, collapse = "\n- ")
        )
      } else if (best_method == "Exhaustive Search" && !is.null(private$.results_exhaustive$best_params)) {
        report_lines <- c(report_lines,
          "### Best Parameters (Exhaustive Search):",
          paste("-", names(private$.results_exhaustive$best_params), ":", 
                private$.results_exhaustive$best_params, collapse = "\n- ")
        )
      }
      
      return(paste(report_lines, collapse = "\n"))
    }
  )
)

# Define %||% operator for default values if not already defined
if (!exists("%||%")) {
  `%||%` <- function(x, y) if (is.null(x) || is.na(x)) y else x
}