# Main Controller Module for OptimML Framework in R
# This module orchestrates the entire application workflow

source("components/utils/print_utils.R", encoding = "UTF-8")

# MainController R6 Class
MainController <- R6::R6Class("MainController",
  public = list(
    # Initialize the controller
    initialize = function() {
      print_application_header()
      print_section_header("Initializing OptimML Framework")
    },
    
    # Main function to run the complete analysis
    run_analysis = function(datasets, selected_dataset, selected_algorithm, settings) {
      print_section_header("Starting Model Analysis")
      
      # Validate inputs
      if (is.null(datasets) || is.null(selected_dataset) || is.null(selected_algorithm)) {
        stop("Missing required parameters for analysis")
      }
      
      if (!selected_dataset %in% names(datasets)) {
        stop(paste("Dataset", selected_dataset, "not found"))
      }
      
      # Get the selected dataset
      data <- datasets[[selected_dataset]]
      print_info(paste("Selected dataset:", selected_dataset))
      print_info(paste("Dataset dimensions:", nrow(data), "x", ncol(data)))
      
      # Setup parallel processing if enabled
      if (settings$use_parallel) {
        print_info(paste("Setting up parallel processing with", settings$n_cores, "cores"))
        cl <- makeCluster(settings$n_cores)
        registerDoParallel(cl)
        on.exit(stopCluster(cl))
      }
      
      # Preprocess data
      print_subsection_header("Data Preprocessing")
      processed_data <- self$preprocess_data(data, settings$test_size)
      
      # Initialize evaluators
      print_subsection_header("Model Training")
      
      # Create evaluator
      evaluator <- ModelEvaluator$new(
        X_train = processed_data$X_train,
        X_test = processed_data$X_test,
        y_train = processed_data$y_train,
        y_test = processed_data$y_test
      )
      
      # Run genetic algorithm optimization
      print_info("Running genetic algorithm optimization...")
      start_time <- Sys.time()
      genetic_results <- evaluator$genetic_search(
        algorithm = selected_algorithm,
        settings = settings
      )
      genetic_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
      
      # Run exhaustive search optimization
      print_info("Running exhaustive search optimization...")
      start_time <- Sys.time()
      exhaustive_results <- evaluator$exhaustive_search(
        algorithm = selected_algorithm,
        settings = settings
      )
      exhaustive_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
      
      # Evaluate results
      print_subsection_header("Model Evaluation")
      predictor <- Predictor$new(processed_data$X_test, processed_data$y_test)
      
      genetic_evaluation <- predictor$evaluate_model(genetic_results$model)
      genetic_evaluation$training_time <- genetic_time
      genetic_evaluation$best_params <- genetic_results$best_params
      
      exhaustive_evaluation <- predictor$evaluate_model(exhaustive_results$model)
      exhaustive_evaluation$training_time <- exhaustive_time
      exhaustive_evaluation$best_params <- exhaustive_results$best_params
      
      print_success("Analysis completed successfully")
      
      # Return results
      return(list(
        genetic = genetic_evaluation,
        exhaustive = exhaustive_evaluation
      ))
    },
    
    # Preprocess data function
    preprocess_data = function(data, test_size = 0.3) {
      print_info("Preprocessing data...")
      
      # Check if defects column exists
      if (!"defects" %in% names(data)) {
        stop("Dataset must contain a 'defects' column")
      }
      
      # Remove rows with missing values
      data_clean <- na.omit(data)
      removed_rows <- nrow(data) - nrow(data_clean)
      if (removed_rows > 0) {
        print_info(paste("Removed", removed_rows, "rows with missing values"))
      }
      
      # Separate features and target
      X <- data_clean[, !names(data_clean) %in% "defects"]
      y <- log(data_clean$defects + 1)  # Log transformation
      
      # Create train/test split
      set.seed(42)  # For reproducibility
      train_indices <- sample(1:nrow(X), size = floor((1 - test_size) * nrow(X)))
      
      X_train <- X[train_indices, ]
      X_test <- X[-train_indices, ]
      y_train <- y[train_indices]
      y_test <- y[-train_indices]
      
      # Scale features
      print_info("Scaling features...")
      
      # Calculate scaling parameters from training data
      means <- sapply(X_train, mean, na.rm = TRUE)
      sds <- sapply(X_train, sd, na.rm = TRUE)
      
      # Apply scaling
      X_train_scaled <- scale(X_train)
      X_test_scaled <- scale(X_test, center = means, scale = sds)
      
      print_success(paste("Data preprocessing complete. Training set:", nrow(X_train_scaled), 
                         "samples, Test set:", nrow(X_test_scaled), "samples"))
      
      return(list(
        X_train = X_train_scaled,
        X_test = X_test_scaled,
        y_train = y_train,
        y_test = y_test
      ))
    }
  )
)