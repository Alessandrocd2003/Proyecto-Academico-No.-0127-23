# Data Generation and Preprocessing Module for OptimML Framework in R
# This module handles all data-related operations

library(R6)
library(readr)
library(dplyr)
library(DBI)

source("components/utils/print_utils.R", encoding = "UTF-8")

# DataGenerator R6 Class
DataGenerator <- R6::R6Class("DataGenerator",
  private = list(
    .file_paths = NULL,
    .use_sql = FALSE,
    .db_params = NULL,
    .dfs = list(),
    .con = NULL
  ),
  
  public = list(
    # Initialize the DataGenerator
    initialize = function(file_paths, use_sql = FALSE, db_params = NULL) {
      private$.file_paths <- file_paths
      private$.use_sql <- use_sql
      private$.db_params <- db_params
      
      print_subsection_header("Initializing Data Generator")
      print_info(paste("Number of files to process:", length(file_paths)))
      
      if (use_sql && !is.null(db_params)) {
        print_info("SQL database mode enabled")
        self$create_db_connection()
      } else {
        print_info("CSV file mode enabled")
      }
    },
    
    # Create database connection
    create_db_connection = function() {
      if (private$.use_sql && !is.null(private$.db_params)) {
        print_info("Creating database connection...")
        
        tryCatch({
          # This would need to be adapted based on the specific database system
          # Example for SQLite
          private$.con <- DBI::dbConnect(RSQLite::SQLite(), 
                                       dbname = private$.db_params$database)
          print_success("Database connection established")
        }, error = function(e) {
          print_error(paste("Database connection failed:", e$message))
          private$.use_sql <- FALSE
        })
      }
    },
    
    # Load data from CSV files or SQL database
    load_data = function() {
      print_subsection_header("Loading Datasets")
      
      if (private$.use_sql && !is.null(private$.con)) {
        self$load_from_sql()
      } else {
        self$load_from_csv()
      }
      
      # Clean data by removing missing values
      self$clean_data()
      
      print_success(paste("Successfully loaded", length(private$.dfs), "datasets"))
      
      return(private$.dfs)
    },
    
    # Load data from CSV files
    load_from_csv = function() {
      file_count <- length(private$.file_paths)
      
      for (i in seq_along(private$.file_paths)) {
        file_path <- private$.file_paths[i]
        dataset_name <- tools::file_path_sans_ext(basename(file_path))
        
        print_data_loading(dataset_name, i, file_count)
        
        tryCatch({
          # Read CSV file
          df <- readr::read_csv(file_path, show_col_types = FALSE)
          
          # Convert to data.frame if tibble
          if (inherits(df, "tbl")) {
            df <- as.data.frame(df)
          }
          
          private$.dfs[[dataset_name]] <- df
          print_info(paste("Loaded", dataset_name, "with", nrow(df), "rows and", ncol(df), "columns"))
          
        }, error = function(e) {
          print_error(paste("Failed to load", dataset_name, ":", e$message))
        })
      }
    },
    
    # Load data from SQL database
    load_from_sql = function() {
      if (is.null(private$.con)) {
        print_error("No database connection available")
        return()
      }
      
      # First, save CSV data to SQL tables
      for (file_path in private$.file_paths) {
        dataset_name <- tools::file_path_sans_ext(basename(file_path))
        table_name <- paste0(dataset_name, "_table")
        
        print_info(paste("Loading and saving", dataset_name, "to SQL database..."))
        
        tryCatch({
          # Read CSV file
          df <- readr::read_csv(file_path, show_col_types = FALSE)
          
          # Write to database
          DBI::dbWriteTable(private$.con, table_name, df, overwrite = TRUE)
          print_success(paste("Saved", dataset_name, "to database"))
          
        }, error = function(e) {
          print_error(paste("Failed to save", dataset_name, "to database:", e$message))
        })
      }
      
      # Then read from SQL tables
      for (file_path in private$.file_paths) {
        dataset_name <- tools::file_path_sans_ext(basename(file_path))
        table_name <- paste0(dataset_name, "_table")
        
        print_info(paste("Reading", dataset_name, "from SQL database..."))
        
        tryCatch({
          df <- DBI::dbReadTable(private$.con, table_name)
          private$.dfs[[dataset_name]] <- df
          print_success(paste("Loaded", dataset_name, "from database"))
          
        }, error = function(e) {
          print_error(paste("Failed to read", dataset_name, "from database:", e$message))
        })
      }
    },
    
    # Clean data by removing missing values
    clean_data = function() {
      print_subsection_header("Cleaning Data")
      
      for (dataset_name in names(private$.dfs)) {
        original_rows <- nrow(private$.dfs[[dataset_name]])
        
        # Remove rows with any missing values
        private$.dfs[[dataset_name]] <- na.omit(private$.dfs[[dataset_name]])
        
        removed_rows <- original_rows - nrow(private$.dfs[[dataset_name]])
        
        if (removed_rows > 0) {
          print_info(paste("Removed", removed_rows, "rows with missing values from", dataset_name))
        }
      }
    },
    
    # Preprocess data and create train/test splits
    preprocess_data = function(test_size = 0.3) {
      print_subsection_header("Preprocessing Data")
      
      X_trains <- list()
      X_tests <- list()
      y_trains <- list()
      y_tests <- list()
      
      for (dataset_name in names(private$.dfs)) {
        print_info(paste("Preprocessing dataset:", dataset_name))
        
        df <- private$.dfs[[dataset_name]]
        
        # Check if defects column exists
        if (!"defects" %in% names(df)) {
          print_warning(paste("Dataset", dataset_name, "does not have 'defects' column. Skipping."))
          next
        }
        
        # Separate features and target
        X <- df[, !names(df) %in% "defects"]
        y <- log(df$defects + 1)  # Log transformation
        
        # Create train/test split
        set.seed(42)  # For reproducibility
        train_indices <- sample(1:nrow(X), size = floor((1 - test_size) * nrow(X)))
        
        X_train <- X[train_indices, ]
        X_test <- X[-train_indices, ]
        y_train <- y[train_indices]
        y_test <- y[-train_indices]
        
        print_info(paste("Split", dataset_name, "into", nrow(X_train), "training and", nrow(X_test), "testing samples"))
        
        X_trains[[dataset_name]] <- X_train
        X_tests[[dataset_name]] <- X_test
        y_trains[[dataset_name]] <- y_train
        y_tests[[dataset_name]] <- y_test
      }
      
      print_success("Data preprocessing complete")
      
      return(list(
        X_trains = X_trains,
        X_tests = X_tests,
        y_trains = y_trains,
        y_tests = y_tests
      ))
    },
    
    # Scale features using standardization
    scale_features = function(X_trains, X_tests) {
      print_subsection_header("Scaling Features")
      
      for (dataset_name in names(X_trains)) {
        print_info(paste("Scaling features for dataset:", dataset_name))
        
        # Calculate scaling parameters from training data
        means <- sapply(X_trains[[dataset_name]], mean, na.rm = TRUE)
        sds <- sapply(X_trains[[dataset_name]], sd, na.rm = TRUE)
        
        # Apply scaling
        X_trains[[dataset_name]] <- scale(X_trains[[dataset_name]])
        X_tests[[dataset_name]] <- scale(X_tests[[dataset_name]], center = means, scale = sds)
        
        print_success(paste("Scaling complete for dataset:", dataset_name))
      }
      
      print_success("Feature scaling complete for all datasets")
      
      return(list(
        X_trains = X_trains,
        X_tests = X_tests
      ))
    },
    
    # Print exploratory data analysis
    print_eda = function() {
      print_subsection_header("Exploratory Data Analysis")
      
      for (dataset_name in names(private$.dfs)) {
        df <- private$.dfs[[dataset_name]]
        
        print_subsection_header(paste("EDA for dataset:", dataset_name))
        
        # Basic statistics
        cat("Dataset dimensions:", nrow(df), "x", ncol(df), "\n")
        cat("Missing values:", sum(is.na(df)), "\n")
        
        if ("defects" %in% names(df)) {
          cat("Target variable (defects) summary:\n")
          print(summary(df$defects))
          
          # Target distribution
          defect_counts <- table(df$defects)
          cat("\nDefects distribution:\n")
          print(defect_counts)
        }
        
        # Correlation with target if available
        if ("defects" %in% names(df)) {
          numeric_cols <- sapply(df, is.numeric)
          if (sum(numeric_cols) > 1) {
            correlations <- cor(df[numeric_cols], use = "complete.obs")
            if ("defects" %in% rownames(correlations)) {
              cat("\nCorrelations with defects:\n")
              defect_cors <- correlations[, "defects"]
              defect_cors <- defect_cors[names(defect_cors) != "defects"]
              defect_cors <- sort(defect_cors, decreasing = TRUE)
              print(defect_cors)
            }
          }
        }
        
        cat("\n", rep("=", 50), "\n")
      }
    },
    
    # Get the processed data
    get_data = function() {
      return(private$.dfs)
    },
    
    # Process all steps
    process = function() {
      self$load_data()
      self$print_eda()
      processed <- self$preprocess_data()
      scaled <- self$scale_features(processed$X_trains, processed$X_tests)
      
      return(list(
        X_trains = scaled$X_trains,
        X_tests = scaled$X_tests,
        y_trains = processed$y_trains,
        y_tests = processed$y_tests
      ))
    },
    
    # Finalize - clean up database connection
    finalize = function() {
      if (!is.null(private$.con)) {
        DBI::dbDisconnect(private$.con)
        print_info("Database connection closed")
      }
    }
  )
)