
# UI snippet that you can include in your settings box:
shiny::checkboxInput("rf_force_sequential", "Forzar secuencial para RandomForest (macOS/Shiny recomendado)", value = TRUE)
