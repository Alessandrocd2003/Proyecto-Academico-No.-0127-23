# Print Utilities Module for OptimML Framework in R
# This module provides standardized print formatting functions

# ANSI color codes for terminal output (if supported)
if (.Platform$OS.type == "unix") {
  # Unix/Linux/Mac systems typically support ANSI colors
  COLORS <- list(
    HEADER = '\033[95m',
    BLUE = '\033[94m',
    CYAN = '\033[96m',
    GREEN = '\033[92m',
    YELLOW = '\033[93m',
    RED = '\033[91m',
    ENDC = '\033[0m',
    BOLD = '\033[1m',
    UNDERLINE = '\033[4m'
  )
} else {
  # Windows systems might not support ANSI colors in all terminals
  COLORS <- list(
    HEADER = '',
    BLUE = '',
    CYAN = '',
    GREEN = '',
    YELLOW = '',
    RED = '',
    ENDC = '',
    BOLD = '',
    UNDERLINE = ''
  )
}

#' Print a formatted section header
#'
#' @param title Character string with the title of the section
print_section_header <- function(title) {
  width <- 80
  cat("\n", rep("=", width), "\n", sep = "")
  spaces_needed <- max(0, width - nchar(title))
  left_spaces <- floor(spaces_needed / 2)
  right_spaces <- spaces_needed - left_spaces
  
  cat(COLORS$BOLD, COLORS$BLUE, 
      rep(" ", left_spaces), title, rep(" ", right_spaces),
      COLORS$ENDC, "\n", sep = "")
  cat(rep("=", width), "\n", sep = "")
}

#' Print a formatted subsection header
#'
#' @param title Character string with the title of the subsection
print_subsection_header <- function(title) {
  width <- 80
  cat("\n", rep("-", width), "\n", sep = "")
  cat(COLORS$BOLD, COLORS$CYAN, title, COLORS$ENDC, "\n", sep = "")
  cat(rep("-", width), "\n", sep = "")
}

#' Print an informational message
#'
#' @param message Character string with the message to print
print_info <- function(message) {
  cat(COLORS$BLUE, "[INFO]", COLORS$ENDC, " ", message, "\n", sep = "")
}

#' Print a success message
#'
#' @param message Character string with the message to print
print_success <- function(message) {
  cat(COLORS$GREEN, "[SUCCESS]", COLORS$ENDC, " ", message, "\n", sep = "")
}

#' Print a warning message
#'
#' @param message Character string with the message to print
print_warning <- function(message) {
  cat(COLORS$YELLOW, "[WARNING]", COLORS$ENDC, " ", message, "\n", sep = "")
}

#' Print an error message
#'
#' @param message Character string with the message to print
print_error <- function(message) {
  cat(COLORS$RED, "[ERROR]", COLORS$ENDC, " ", message, "\n", sep = "")
}

#' Print a progress bar
#'
#' @param current Integer with current progress value
#' @param total Integer with total value representing 100% completion
#' @param message Character string with additional message to display
print_progress <- function(current, total, message = "") {
  bar_length <- 40
  progress <- current / total
  arrow_length <- round(progress * bar_length)
  arrow <- paste(rep("█", arrow_length), collapse = "")
  spaces <- paste(rep(" ", bar_length - arrow_length), collapse = "")
  
  percentage <- round(progress * 100)
  
  cat("\r[", arrow, spaces, "] ", percentage, "% ", message, sep = "")
  
  if (current == total) {
    cat("\n")  # New line when complete
  }
}

#' Print a timestamp message
#'
#' @param message Character string with the message to print
print_timestamp <- function(message) {
  timestamp <- format(Sys.time(), "%Y-%m-%d %H:%M:%S")
  cat("[", timestamp, "] ", message, "\n", sep = "")
}

#' Print data loading progress
#'
#' @param dataset_name Character string with the name of the dataset being loaded
#' @param current Integer with current file number
#' @param total Integer with total number of files
print_data_loading <- function(dataset_name, current, total) {
  cat(sprintf("[%d/%d] Loading dataset: %s\n", current, total, dataset_name))
}

#' Print application header
print_application_header <- function() {
  cat("\n")
  print_section_header("OptimML Framework - R Implementation")
  cat("Machine Learning Model Optimization Framework\n")
  cat("Supports Genetic Algorithm and Exhaustive Search Hyperparameter Optimization\n")
  cat("With Parallel Processing and Interactive Shiny Dashboard\n")
  cat("\nVersion: 1.0.0\n")
  cat("Language: R\n")
  print_timestamp("Application started")
}

#' Print model training start message
#'
#' @param model_name Character string with the name of the model
#' @param method Character string with the optimization method ("genetic" or "exhaustive")
print_model_training_start <- function(model_name, method) {
  method_display <- switch(method,
    "genetic" = "Genetic Algorithm",
    "exhaustive" = "Exhaustive Search",
    method
  )
  print_info(paste("Starting", method_display, "optimization for", model_name))
}

#' Print model training completion message
#'
#' @param model_name Character string with the name of the model
#' @param method Character string with the optimization method
#' @param training_time Numeric with the training time in seconds
#' @param metrics List with performance metrics
print_model_training_complete <- function(model_name, method, training_time, metrics = NULL) {
  method_display <- switch(method,
    "genetic" = "Genetic Algorithm",
    "exhaustive" = "Exhaustive Search", 
    method
  )
  
  message <- paste(method_display, "optimization completed for", model_name)
  message <- paste(message, sprintf("(%.2f seconds)", training_time))
  
  if (!is.null(metrics)) {
    if ("fitness" %in% names(metrics)) {
      message <- paste(message, sprintf("- Best fitness: %.4f", metrics$fitness))
    }
    if ("best_rmse" %in% names(metrics)) {
      message <- paste(message, sprintf("- Best RMSE: %.4f", metrics$best_rmse))
    }
  }
  
  print_success(message)
}

#' Print a table with headers and data
#'
#' @param headers Character vector with column headers
#' @param data List of character vectors, each representing a row
print_table <- function(headers, data) {
  if (length(headers) == 0 || length(data) == 0) {
    return()
  }
  
  # Calculate column widths
  col_widths <- nchar(headers)
  
  for (row in data) {
    for (i in seq_along(row)) {
      if (i <= length(col_widths)) {
        col_widths[i] <- max(col_widths[i], nchar(as.character(row[i])))
      }
    }
  }
  
  # Add padding
  col_widths <- col_widths + 2
  
  # Print header
  header_line <- ""
  separator_line <- ""
  
  for (i in seq_along(headers)) {
    header_text <- sprintf("%-*s", col_widths[i], headers[i])
    header_line <- paste0(header_line, header_text)
    separator_line <- paste0(separator_line, paste(rep("-", col_widths[i]), collapse = ""))
  }
  
  cat(header_line, "\n")
  cat(separator_line, "\n")
  
  # Print data rows
  for (row in data) {
    row_line <- ""
    for (i in seq_along(row)) {
      if (i <= length(col_widths)) {
        cell_text <- sprintf("%-*s", col_widths[i], as.character(row[i]))
        row_line <- paste0(row_line, cell_text)
      }
    }
    cat(row_line, "\n")
  }
  
  cat("\n")
}

#' Print summary statistics
#'
#' @param title Character string with the title for the statistics
#' @param stats Named list with statistics to display
print_summary_statistics <- function(title, stats) {
  print_subsection_header(title)
  
  for (name in names(stats)) {
    value <- stats[[name]]
    if (is.numeric(value)) {
      value_str <- sprintf("%.4f", value)
    } else {
      value_str <- as.character(value)
    }
    cat(sprintf("%-20s: %s\n", name, value_str))
  }
  
  cat("\n")
}

#' Print a separator line
#'
#' @param char Character to use for the separator (default: "-")
#' @param width Integer width of the separator line (default: 80)
print_separator <- function(char = "-", width = 80) {
  cat(rep(char, width), "\n", sep = "")
}

#' Print execution time
#'
#' @param start_time POSIXct with the start time
#' @param end_time POSIXct with the end time (default: current time)
print_execution_time <- function(start_time, end_time = Sys.time()) {
  duration <- difftime(end_time, start_time, units = "secs")
  duration_str <- sprintf("%.2f seconds", as.numeric(duration))
  print_info(paste("Execution time:", duration_str))
}

#' Print memory usage information
print_memory_usage <- function() {
  if (.Platform$OS.type == "unix") {
    # On Unix systems, try to get memory info
    tryCatch({
      memory_info <- system("ps -o pid,vsz,rss,comm -p $PPID", intern = TRUE)
      print_info("Memory usage information:")
      cat(paste(memory_info, collapse = "\n"), "\n")
    }, error = function(e) {
      print_info("Memory usage information not available")
    })
  } else {
    # On Windows, provide basic R memory info
    memory_size <- memory.size()
    memory_limit <- memory.limit()
    print_info(sprintf("R memory usage: %.1f MB (limit: %.1f MB)", memory_size, memory_limit))
  }
}

#' Print system information
print_system_info <- function() {
  print_subsection_header("System Information")
  
  # R version
  cat("R Version:", R.version.string, "\n")
  
  # Platform
  cat("Platform:", R.version$platform, "\n")
  
  # OS
  cat("Operating System:", Sys.info()["sysname"], Sys.info()["release"], "\n")
  
  # Number of cores
  cat("CPU Cores:", parallel::detectCores(), "\n")
  
  # Memory info (if available)
  if (.Platform$OS.type != "unix") {
    tryCatch({
      cat("Memory Limit:", memory.limit(), "MB\n")
    }, error = function(e) {
      cat("Memory information not available\n")
    })
  }
  
  cat("\n")
}

#' Print package versions for key dependencies
print_package_versions <- function() {
  print_subsection_header("Package Versions")
  
  key_packages <- c("shiny", "plotly", "DT", "parallel", "doParallel", 
                   "foreach", "caret", "randomForest", "glmnet", "xgboost")
  
  for (pkg in key_packages) {
    tryCatch({
      version <- as.character(packageVersion(pkg))
      cat(sprintf("%-15s: %s\n", pkg, version))
    }, error = function(e) {
      cat(sprintf("%-15s: Not installed\n", pkg))
    })
  }
  
  cat("\n")
}