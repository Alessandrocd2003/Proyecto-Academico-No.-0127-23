# Model Prediction and Evaluation Module for OptimML Framework in R
# This module is responsible for making predictions and evaluating model performance

library(R6)

source("components/utils/print_utils.R", encoding = "UTF-8")

# Predictor R6 Class
Predictor <- R6::R6Class("Predictor",
  private = list(
    .X_test = NULL,
    .y_test = NULL
  ),
  
  public = list(
    # Initialize the Predictor
    initialize = function(X_test, y_test) {
      private$.X_test <- X_test
      private$.y_test <- y_test
      
      print_info("Predictor initialized")
      print_info(paste("Test set size:", nrow(X_test), "x", ncol(X_test)))
    },
    
    # Make predictions using a trained model
    predict = function(model, algorithm) {
      print_info(paste("Making predictions with", algorithm))
      
      predictions <- switch(algorithm,
        "LinearRegression" = {
          predict(model, newdata = data.frame(private$.X_test))
        },
        
        "DecisionTree" = {
          predict(model, newdata = data.frame(private$.X_test))
        },
        
        "RandomForest" = {
          predict(model, newdata = private$.X_test)
        },
        
        "Lasso" = ,
        "Ridge" = {
          as.vector(predict(model, newx = as.matrix(private$.X_test)))
        },
        
        "KNN" = {
          # For KNN, the model contains the training data and parameters
          FNN::knn.reg(
            train = model$X_train,
            test = private$.X_test,
            y = model$y_train,
            k = model$k
          )$pred
        },
        
        "XGBoost" = {
          predict(model, as.matrix(private$.X_test))
        },
        
        stop(paste("Unknown algorithm:", algorithm))
      )
      
      return(predictions)
    },
    
    # Evaluate predictions using various metrics
    evaluate = function(y_pred) {
      print_info("Evaluating model performance...")
      
      # Calculate metrics
      r2 <- self$calculate_r2(private$.y_test, y_pred)
      mse <- mean((private$.y_test - y_pred)^2)
      rmse <- sqrt(mse)
      mae <- mean(abs(private$.y_test - y_pred))
      
      # Create metrics list
      metrics <- list(
        r2 = r2,
        mse = mse,
        rmse = rmse,
        mae = mae
      )
      
      # Print metrics table
      metrics_df <- data.frame(
        Metric = c("R² Score", "Mean Squared Error", "Root Mean Squared Error", "Mean Absolute Error"),
        Value = c(sprintf("%.4f", r2), sprintf("%.4f", mse), sprintf("%.4f", rmse), sprintf("%.4f", mae)),
        stringsAsFactors = FALSE
      )
      
      print_table(c("Metric", "Value"), 
                 list(c("R² Score", sprintf("%.4f", r2)),
                      c("Mean Squared Error", sprintf("%.4f", mse)),
                      c("Root Mean Squared Error", sprintf("%.4f", rmse)),
                      c("Mean Absolute Error", sprintf("%.4f", mae))))
      
      return(metrics)
    },
    
    # Calculate R-squared score
    calculate_r2 = function(y_true, y_pred) {
      ss_res <- sum((y_true - y_pred)^2)
      ss_tot <- sum((y_true - mean(y_true))^2)
      r2 <- 1 - (ss_res / ss_tot)
      return(r2)
    },
    
    # Evaluate a trained model (combines prediction and evaluation)
    evaluate_model = function(model, algorithm = NULL) {
      print_subsection_header("Model Evaluation")
      
      # If algorithm is not provided, try to infer it from model class
      if (is.null(algorithm)) {
        algorithm <- self$infer_algorithm(model)
      }
      
      print_info(paste("Evaluating", algorithm, "model"))
      
      # Time the prediction
      start_time <- Sys.time()
      y_pred <- self$predict(model, algorithm)
      prediction_time <- as.numeric(difftime(Sys.time(), start_time, units = "secs"))
      
      # Evaluate predictions
      metrics <- self$evaluate(y_pred)
      
      # Add prediction time to metrics
      metrics$prediction_time <- prediction_time
      
      print_success(paste("Evaluation complete for", algorithm))
      
      return(metrics)
    },
    
    # Infer algorithm from model class
    
infer_algorithm = function(model) {
      classes <- class(model)
      
      # Helper: detect Lasso vs Ridge for glmnet/elnet by alpha
      infer_glmnet <- function(model) {
        a <- tryCatch(eval(model$call$alpha), error = function(e) NA_real_)
        if (is.finite(a)) {
          if (abs(a - 1) < 1e-8) return("Lasso")
          if (abs(a - 0) < 1e-8) return("Ridge")
        }
        # Fallback default
        return("Lasso")
      }
      
      if ("lm" %in% classes) return("LinearRegression")
      if ("rpart" %in% classes) return("DecisionTree")
      if ("randomForest" %in% classes) return("RandomForest")
      if (any(c("glmnet", "elnet") %in% classes)) return(infer_glmnet(model))
      if ("xgb.Booster" %in% classes) return("XGBoost")
      if ("list" %in% classes) return("KNN")  # our KNN implementation returns a list
      
      print_warning(paste("Could not infer algorithm from model classes:", paste(classes, collapse = ",")))
      return("Unknown")
    },
      
    
    # Evaluate multiple models and compare results
    evaluate_multiple_models = function(models, algorithms = NULL) {
      print_subsection_header("Multiple Model Evaluation")
      
      if (is.null(algorithms)) {
        algorithms <- names(models)
      }
      
      if (length(models) != length(algorithms)) {
        stop("Number of models must match number of algorithm names")
      }
      
      evaluation_results <- list()
      
      for (i in seq_along(models)) {
        model <- models[[i]]
        algorithm <- algorithms[i]
        
        print_info(paste("Evaluating model", i, "of", length(models), ":", algorithm))
        
        # Evaluate the model
        metrics <- self$evaluate_model(model, algorithm)
        evaluation_results[[algorithm]] <- metrics
      }
      
      print_success("Multiple model evaluation complete")
      
      return(evaluation_results)
    },
    
    # Compare two models and determine which is better
    compare_models = function(model1, model2, algorithm1, algorithm2) {
      print_subsection_header("Model Comparison")
      
      # Evaluate both models
      metrics1 <- self$evaluate_model(model1, algorithm1)
      metrics2 <- self$evaluate_model(model2, algorithm2)
      
      # Compare RMSE (lower is better)
      if (metrics1$rmse < metrics2$rmse) {
        print_success(paste(algorithm1, "performs better (RMSE:", sprintf("%.4f", metrics1$rmse), 
                           "vs", sprintf("%.4f", metrics2$rmse), ")"))
        winner <- algorithm1
        winner_metrics <- metrics1
      } else {
        print_success(paste(algorithm2, "performs better (RMSE:", sprintf("%.4f", metrics2$rmse), 
                           "vs", sprintf("%.4f", metrics1$rmse), ")"))
        winner <- algorithm2
        winner_metrics <- metrics2
      }
      
      # Create comparison summary
      comparison <- list(
        winner = winner,
        winner_metrics = winner_metrics,
        model1_metrics = metrics1,
        model2_metrics = metrics2,
        improvement = abs(metrics1$rmse - metrics2$rmse)
      )
      
      return(comparison)
    },
    
    # Generate predictions for new data
    predict_new_data = function(model, algorithm, new_data) {
      print_info(paste("Making predictions on new data with", algorithm))
      
      predictions <- switch(algorithm,
        "LinearRegression" = {
          predict(model, newdata = data.frame(new_data))
        },
        
        "DecisionTree" = {
          predict(model, newdata = data.frame(new_data))
        },
        
        "RandomForest" = {
          predict(model, newdata = new_data)
        },
        
        "Lasso" = ,
        "Ridge" = {
          as.vector(predict(model, newx = as.matrix(new_data)))
        },
        
        "KNN" = {
          FNN::knn.reg(
            train = model$X_train,
            test = new_data,
            y = model$y_train,
            k = model$k
          )$pred
        },
        
        "XGBoost" = {
          predict(model, as.matrix(new_data))
        },
        
        stop(paste("Unknown algorithm:", algorithm))
      )
      
      print_success(paste("Generated", length(predictions), "predictions"))
      
      return(predictions)
    },
    
    # Calculate prediction intervals (for models that support it)
    calculate_prediction_intervals = function(model, algorithm, confidence = 0.95) {
      print_info(paste("Calculating prediction intervals for", algorithm))
      
      if (algorithm %in% c("LinearRegression")) {
        # For linear regression, we can calculate prediction intervals
        pred_data <- data.frame(private$.X_test)
        predictions <- predict(model, newdata = pred_data, interval = "prediction", level = confidence)
        
        return(list(
          fit = predictions[, "fit"],
          lower = predictions[, "lwr"],
          upper = predictions[, "upr"]
        ))
      } else {
        print_warning(paste("Prediction intervals not implemented for", algorithm))
        return(NULL)
      }
    }
  )
)