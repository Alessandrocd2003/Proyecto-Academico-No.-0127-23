# setup_environment.R
# Environment setup script for OptimML Framework R implementation

cat("========================================\n")
cat("OptimML Framework - Environment Setup\n")
cat("========================================\n\n")

# Check R version
r_version <- R.version.string
cat("R Version:", r_version, "\n")

if (as.numeric(R.version$major) < 4) {
  cat("WARNING: R version 4.0.0+ is recommended for best compatibility.\n")
}

# Check system information
cat("Platform:", R.version$platform, "\n")
cat("Operating System:", Sys.info()["sysname"], "\n")
cat("CPU Cores Available:", parallel::detectCores(), "\n\n")

# Create necessary directories
directories <- c("datasets", "results", "logs")
for (dir in directories) {
  if (!dir.exists(dir)) {
    dir.create(dir, recursive = TRUE)
    cat("Created directory:", dir, "\n")
  } else {
    cat("Directory exists:", dir, "\n")
  }
}

# Function to install and load packages
install_and_load <- function(packages) {
  installed_packages <- rownames(installed.packages())
  
  for (pkg in packages) {
    if (!pkg %in% installed_packages) {
      cat("\nInstalling package:", pkg, "\n")
      tryCatch({
        install.packages(pkg, dependencies = TRUE, repos = "https://cran.r-project.org/")
        cat("Successfully installed:", pkg, "\n")
      }, error = function(e) {
        cat("Failed to install:", pkg, "- Error:", e$message, "\n")
      })
    } else {
      cat("Package already installed:", pkg, "\n")
    }
  }
}

# Essential packages for the framework
essential_packages <- c(
  "R6",              # Object-oriented programming
  "shiny",           # Web application framework
  "shinydashboard",  # Dashboard components
  "DT",              # Data tables
  "plotly",          # Interactive plots
  "parallel",        # Parallel processing
  "doParallel",      # Parallel backend
  "foreach"          # Parallel loops
)

# Machine learning packages
ml_packages <- c(
  "caret",           # ML framework
  "randomForest",    # Random forest
  "glmnet",          # Lasso and Ridge
  "xgboost",         # Gradient boosting
  "FNN",             # K-nearest neighbors
  "rpart",           # Decision trees
  "GA"               # Genetic algorithms
)

# Data manipulation and visualization
data_packages <- c(
  "readr",           # Fast data reading
  "dplyr",           # Data manipulation
  "tidyr",           # Data tidying
  "corrplot",        # Correlation plots
  "ggplot2",         # Advanced plotting
  "openxlsx"         # Excel export
)

# Optional packages
optional_packages <- c(
  "DBI",             # Database interface
  "RSQLite",         # SQLite support
  "future",          # Asynchronous programming
  "promises",        # Promise-based programming
  "profvis",         # Profiling
  "microbenchmark",  # Benchmarking
  "stringr",         # String manipulation
  "lubridate",       # Date/time handling
  "jsonlite"         # JSON handling
)

cat("\n" , rep("=", 50), "\n")
cat("Installing Essential Packages...\n")
cat(rep("=", 50), "\n")
install_and_load(essential_packages)

cat("\n", rep("=", 50), "\n")
cat("Installing Machine Learning Packages...\n")
cat(rep("=", 50), "\n")
install_and_load(ml_packages)

cat("\n", rep("=", 50), "\n")
cat("Installing Data Packages...\n")
cat(rep("=", 50), "\n")
install_and_load(data_packages)

cat("\n", rep("=", 50), "\n")
cat("Installing Optional Packages...\n")
cat(rep("=", 50), "\n")
install_and_load(optional_packages)

# Verify critical packages
cat("\n", rep("=", 50), "\n")
cat("Verifying Installation...\n")
cat(rep("=", 50), "\n")

critical_packages <- c("shiny", "R6", "parallel", "caret", "plotly")
failed_packages <- c()

for (pkg in critical_packages) {
  if (require(pkg, character.only = TRUE, quietly = TRUE)) {
    cat("✓ ", pkg, " - OK\n")
  } else {
    cat("✗ ", pkg, " - FAILED\n")
    failed_packages <- c(failed_packages, pkg)
  }
}

# Set up parallel processing configuration
cat("\n", rep("=", 50), "\n")
cat("Configuring Parallel Processing...\n")
cat(rep("=", 50), "\n")

n_cores <- parallel::detectCores()
recommended_cores <- max(1, n_cores - 1)

cat("Total CPU cores:", n_cores, "\n")
cat("Recommended cores for parallel processing:", recommended_cores, "\n")

# Create sample configuration file
config_file <- "config.R"
if (!file.exists(config_file)) {
  config_content <- paste0(
    "# OptimML Framework Configuration\n",
    "# Generated on: ", Sys.time(), "\n\n",
    "# Parallel processing settings\n",
    "N_CORES <- ", recommended_cores, "\n",
    "USE_PARALLEL <- TRUE\n\n",
    "# Model training settings\n",
    "CV_FOLDS <- 5\n",
    "GA_POPULATION <- 10\n",
    "GA_GENERATIONS <- 5\n",
    "TEST_SIZE <- 0.3\n\n",
    "# Shiny app settings\n",
    "SHINY_PORT <- 8080\n",
    "SHINY_HOST <- '127.0.0.1'\n\n",
    "# Paths\n",
    "DATASETS_PATH <- 'datasets'\n",
    "RESULTS_PATH <- 'results'\n",
    "LOGS_PATH <- 'logs'\n"
  )
  
  writeLines(config_content, config_file)
  cat("Created configuration file:", config_file, "\n")
}

# Check for sample datasets
cat("\n", rep("=", 50), "\n")
cat("Checking Sample Data...\n")
cat(rep("=", 50), "\n")

datasets_dir <- "datasets"
csv_files <- list.files(datasets_dir, pattern = "\\.csv$")

if (length(csv_files) > 0) {
  cat("Found", length(csv_files), "CSV files in datasets directory:\n")
  for (file in csv_files) {
    cat("- ", file, "\n")
  }
} else {
  cat("No CSV files found in datasets directory.\n")
  cat("Please add your datasets to the 'datasets' folder.\n")
  
  # Create a sample dataset
  cat("Creating sample dataset for testing...\n")
  
  set.seed(42)
  n_samples <- 100
  sample_data <- data.frame(
    feature1 = rnorm(n_samples, mean = 5, sd = 2),
    feature2 = rnorm(n_samples, mean = 10, sd = 3),
    feature3 = runif(n_samples, min = 0, max = 20),
    feature4 = rpois(n_samples, lambda = 3),
    defects = sample(0:5, n_samples, replace = TRUE, prob = c(0.4, 0.3, 0.15, 0.1, 0.04, 0.01))
  )
  
  sample_file <- file.path(datasets_dir, "sample_data.csv")
  write.csv(sample_data, sample_file, row.names = FALSE)
  cat("Created sample dataset:", sample_file, "\n")
}

# Final summary
cat("\n", rep("=", 50), "\n")
cat("Setup Summary\n")
cat(rep("=", 50), "\n")

if (length(failed_packages) == 0) {
  cat("✓ All critical packages installed successfully!\n")
  cat("✓ Environment setup completed.\n")
  cat("✓ Ready to run OptimML Framework.\n\n")
  
  cat("To start the application:\n")
  cat("1. Double-click 'run_app.bat' (Windows)\n")
  cat("2. Or run: Rscript -e \"shiny::runApp('app.R')\"\n")
} else {
  cat("✗ Some critical packages failed to install:\n")
  for (pkg in failed_packages) {
    cat("  - ", pkg, "\n")
  }
  cat("\nPlease install these packages manually before running the application.\n")
}

cat("\nSetup completed at:", as.character(Sys.time()), "\n")
cat("Check 'config.R' for configuration options.\n")
cat(rep("=", 50), "\n")