@echo off
title OptimML Framework - R Shiny Application

echo ================================================
echo     OptimML Framework - R Implementation
echo ================================================
echo.
echo Starting Shiny application...
echo The application will open in your default web browser.
echo.
echo To stop the application, press Ctrl+C in this window.
echo.

RScript.exe -e "
# Check if Shiny is installed
if (!require('shiny', quietly = TRUE)) {
  cat('Error: Shiny package is not installed.\n')
  cat('Please run install_packages.bat first to install required packages.\n')
  quit(status = 1)
}

# Set options for better performance
options(shiny.maxRequestSize = 100*1024^2)  # 100MB max file upload
options(shiny.reactlog = FALSE)             # Disable reactlog for performance

cat('Loading OptimML Framework...\n')

# Check if required files exist
required_files <- c(
  'app.R',
  'components/RMain.R',
  'components/RGenerator.R', 
  'components/REvaluator.R',
  'components/RPredictor.R',
  'components/RVisualizer.R',
  'components/utils/print_utils.R'
)

missing_files <- c()
for (file in required_files) {
  if (!file.exists(file)) {
    missing_files <- c(missing_files, file)
  }
}

if (length(missing_files) > 0) {
  cat('Error: The following required files are missing:\n')
  for (file in missing_files) {
    cat('-', file, '\n')
  }
  quit(status = 1)
}

# Check if datasets directory exists
if (!dir.exists('datasets')) {
  cat('Warning: datasets directory not found.\n')
  cat('Please ensure you have CSV files in the datasets/ directory.\n')
}

cat('All required files found. Starting application...\n')
cat('Opening browser at: http://127.0.0.1:8080\n')
cat('\nPress Ctrl+C to stop the application.\n\n')

# Run the Shiny app
shiny::runApp('app.R', host = '127.0.0.1', port = 8080, launch.browser = TRUE)
"

echo.
echo Application stopped.
pause
