# GA Configuration for OptimML Framework
# Dataset-specific configurations as per professor's specifications

# GA Operator Configuration (Global)
GA_CROSSOVER_OPERATOR <- "gareal_blxCrossover"
GA_MUTATION_OPERATOR <- "gareal_raMutation"
GA_BASE_PCROSSOVER <- 0.85

# Dataset-specific GA parameters - Ultra-fast execution with 3 runs
# Format: list(popSize, maxiter, pcrossover, pmutation, elitism, run)
GA_DATASET_CONFIGS <- list(
  "ant-1" = list(
    popSize = 50, 
    maxiter = 75, 
    pcrossover = 0.85, 
    pmutation = 0.15, 
    elitism = 3, 
    run = 3,
    n_samples = 745,
    n_features = 21
  ),
  "camel-1" = list(
    popSize = 50, 
    maxiter = 80, 
    pcrossover = 0.85, 
    pmutation = 0.15, 
    elitism = 3, 
    run = 3,
    n_samples = 872,
    n_features = 21
  ),
  "ivy-2" = list(
    popSize = 40, 
    maxiter = 50, 
    pcrossover = 0.85, 
    pmutation = 0.20, 
    elitism = 2, 
    run = 3,
    n_samples = 352,
    n_features = 21
  ),
  "jedit-4D" = list(
    popSize = 30, 
    maxiter = 40, 
    pcrossover = 0.85, 
    pmutation = 0.20, 
    elitism = 2, 
    run = 3,
    n_samples = 306,
    n_features = 7
  ),
  "log4j-1" = list(
    popSize = 30, 
    maxiter = 35, 
    pcrossover = 0.85, 
    pmutation = 0.20, 
    elitism = 2, 
    run = 3,
    n_samples = 135,
    n_features = 21
  ),
  "poi-2" = list(
    popSize = 40, 
    maxiter = 45, 
    pcrossover = 0.85, 
    pmutation = 0.20, 
    elitism = 2, 
    run = 3,
    n_samples = 314,
    n_features = 21
  ),
  "tomcat" = list(
    popSize = 50, 
    maxiter = 80, 
    pcrossover = 0.85, 
    pmutation = 0.15, 
    elitism = 3, 
    run = 3,
    n_samples = 858,
    n_features = 21
  ),
  "velocity-1" = list(
    popSize = 30, 
    maxiter = 35, 
    pcrossover = 0.85, 
    pmutation = 0.20, 
    elitism = 2, 
    run = 3,
    n_samples = 229,
    n_features = 21
  ),
  "xalan-2" = list(
    popSize = 50, 
    maxiter = 70, 
    pcrossover = 0.85, 
    pmutation = 0.15, 
    elitism = 3, 
    run = 3,
    n_samples = 723,
    n_features = 21
  ),
  "xerces-1" = list(
    popSize = 40, 
    maxiter = 55, 
    pcrossover = 0.85, 
    pmutation = 0.15, 
    elitism = 2, 
    run = 3,
    n_samples = 453,
    n_features = 21
  )
)

# Default configuration for unknown datasets - Ultra-fast with 3 runs
GA_DEFAULT_CONFIG <- list(
  popSize = 40, 
  maxiter = 50, 
  pcrossover = 0.85, 
  pmutation = 0.15, 
  elitism = 2, 
  run = 3,
  n_samples = NA,
  n_features = NA
)