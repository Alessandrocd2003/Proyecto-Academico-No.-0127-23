# Required R packages for OptimML Framework
# Install these packages using: install.packages(c("package1", "package2", ...))

# Core R packages
R6                    # Object-oriented programming
readr                 # Fast data reading
dplyr                 # Data manipulation
tidyr                 # Data tidying

# Shiny and web interface
shiny                 # Web application framework
shinydashboard        # Dashboard components for Shiny
DT                    # Interactive data tables
plotly                # Interactive plots
shinyWidgets          # Additional Shiny widgets

# Machine Learning packages
caret                 # Classification and Regression Training
randomForest          # Random Forest implementation
glmnet                # Lasso and Ridge regression
xgboost               # Extreme Gradient Boosting
FNN                   # Fast Nearest Neighbor search
rpart                 # Decision trees
e1071                 # Support Vector Machines and other ML algorithms

# Optimization and genetic algorithms
GA                    # Genetic algorithms
genalg                # Alternative genetic algorithm package

# Parallel processing
parallel              # Parallel computation
doParallel            # Parallel backend for foreach
foreach               # Parallel loops

# Data visualization
corrplot              # Correlation plots
ggplot2               # Grammar of graphics plotting
gridExtra             # Arrange multiple plots

# Data export
openxlsx              # Excel file creation and manipulation
writexl               # Alternative Excel export

# Database connectivity (optional)
DBI                   # Database interface
RSQLite               # SQLite database
RMySQL                # MySQL database (if needed)
RPostgreSQL           # PostgreSQL database (if needed)

# Utility packages
tools                 # File and path utilities
future                # Asynchronous programming
promises              # Promise-based programming

# Performance and profiling
profvis               # Interactive profiling
microbenchmark        # Benchmarking

# Additional utility packages
stringr               # String manipulation
lubridate             # Date and time manipulation
jsonlite              # JSON parsing