# OptimML Framework - Main Application Entry Point in R
# Shiny Application for Machine Learning Model Optimization Framework

# Load required libraries with error handling
required_packages <- c("shiny", "shinydashboard", "DT", "plotly", "dplyr",
                      "readr", "corrplot", "parallel", "doParallel", "foreach",
                      "openxlsx", "R6", "future", "promises")

# Check and load packages
missing_packages <- c()
for (pkg in required_packages) {
  if (!require(pkg, character.only = TRUE, quietly = TRUE)) {
    missing_packages <- c(missing_packages, pkg)
  }
}

if (length(missing_packages) > 0) {
  stop(paste("Missing required packages:", paste(missing_packages, collapse = ", "),
            "\nPlease install them using install_packages.bat or manually with install.packages()"))
}

# Source R component files with error handling
component_files <- c(
  "components/utils/print_utils.R",
  "components/RGenerator.R",
  "components/REvaluator.R",
  "components/RPredictor.R",
  "components/RVisualizer.R",
  "components/RMain.R"
)

for (file in component_files) {
  if (file.exists(file)) {
    tryCatch({
      source(file, encoding = "UTF-8")
    }, error = function(e) {
      stop(paste("Error loading", file, ":", e$message))
    })
  } else {
    stop(paste("Required file not found:", file))
  }
}

# Load GA configuration
if (file.exists("ga_config.R")) {
  source("ga_config.R")
}

# Load configuration if available
if (file.exists("config.R")) {
  source("config.R")
} else {
  # Default configuration
  N_CORES <- max(1, detectCores() - 1)
  USE_PARALLEL <- TRUE
  CV_FOLDS <- 5
  GA_POPULATION <- 10
  GA_GENERATIONS <- 5
  TEST_SIZE <- 0.3
  SHINY_PORT <- 8080
  SHINY_HOST <- '127.0.0.1'
}

# Dataset-specific GA configuration function
get_dataset_ga_config <- function(dataset_name) {
  # Extract base name without extension
  base_name <- tools::file_path_sans_ext(basename(dataset_name))
  
  # Use external configuration if available
  if (exists("GA_DATASET_CONFIGS") && base_name %in% names(GA_DATASET_CONFIGS)) {
    return(GA_DATASET_CONFIGS[[base_name]])
  } else if (exists("GA_DEFAULT_CONFIG")) {
    return(GA_DEFAULT_CONFIG)
  } else {
    # Fallback configuration
    return(list(
      popSize = 126, maxiter = 100, pcrossover = 0.85, pmutation = 0.15, elitism = 7, run = 30
    ))
  }
}

# Define UI
ui <- dashboardPage(
  dashboardHeader(title = "OptimML Framework Dashboard"),

  dashboardSidebar(
    sidebarMenu(
      menuItem("Exploratory Data Analysis", tabName = "eda", icon = icon("chart-bar")),
      menuItem("Model Results", tabName = "results", icon = icon("cogs")),
      menuItem("Settings", tabName = "settings", icon = icon("gear"))
    )
  ),

  dashboardBody(
    tags$head(
      tags$style(HTML("
        .content-wrapper, .right-side {
          background-color: #f4f4f4;
        }
        .main-header .logo {
          background-color: #3c8dbc !important;
        }
        .main-header .navbar {
          background-color: #3c8dbc !important;
        }
        
        /* Professional Data Summary Styles */
        .data-summary-container {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .summary-card {
          background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
          border: 1px solid #e9ecef;
          border-radius: 8px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .summary-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 8px rgba(0,0,0,0.15);
        }
        
        .summary-header {
          background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
          color: white;
          padding: 10px 15px;
          border-radius: 8px 8px 0 0;
          border-bottom: 3px solid #0056b3;
        }
        
        .summary-header.categorical {
          background: linear-gradient(135deg, #28a745 0%, #1e7e34 100%);
          border-bottom-color: #1e7e34;
        }
        
        .stat-badge {
          display: inline-block;
          padding: 4px 10px;
          border-radius: 15px;
          font-size: 11px;
          font-weight: 600;
          margin: 2px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .overview-stats {
          background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
          border-radius: 8px;
          padding: 20px;
          margin-bottom: 20px;
          box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .stat-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
          gap: 12px;
          margin-top: 12px;
        }
        
        .stat-item {
          background: white;
          padding: 8px 12px;
          border-radius: 6px;
          border: 1px solid #dee2e6;
          font-size: 13px;
        }
        
        .stat-label {
          font-weight: 600;
          color: #495057;
          margin-right: 8px;
        }
        
        .stat-value {
          color: #007bff;
          font-weight: 500;
        }
        
        .na-warning {
          background-color: #fff3cd;
          border: 1px solid #ffeaa7;
          color: #856404;
          padding: 6px 10px;
          border-radius: 4px;
          margin-top: 10px;
          font-size: 12px;
        }
      "))
    ),

    tabItems(
      # EDA Tab
      tabItem(tabName = "eda",
        fluidRow(
          box(
            title = "Dataset Selection", status = "primary", solidHeader = TRUE, width = 12,
            selectInput("dataset_eda", "Select Dataset:", choices = NULL, width = "100%")
          )
        ),

        fluidRow(
          box(
            title = "Data Summary", status = "primary", solidHeader = TRUE, width = 6,
            div(
              style = "max-height: 400px; overflow-y: auto;",
              htmlOutput("data_summary")
            )
          ),

          box(
            title = "Missing Values", status = "info", solidHeader = TRUE, width = 6,
            DT::dataTableOutput("missing_values")
          )
        ),

        fluidRow(
          box(
            title = "Correlation Heatmap", status = "primary", solidHeader = TRUE, width = 12,
            plotlyOutput("correlation_heatmap", height = "500px")
          )
        ),

        fluidRow(
          box(
            title = "Distribution Plots", status = "primary", solidHeader = TRUE, width = 6,
            fluidRow(
              column(12, 
                selectInput("variable_histogram", "Select Variable:", 
                           choices = NULL, width = "100%")
              )
            ),
            plotlyOutput("histogram_plot", height = "350px")
          ),

          box(
            title = "Box Plots", status = "primary", solidHeader = TRUE, width = 6,
            fluidRow(
              column(12, 
                selectInput("variable_boxplot", "Select Variable:", 
                           choices = NULL, width = "100%")
              )
            ),
            plotlyOutput("boxplot", height = "350px")
          )
        )
      ),

      # Results Tab
      tabItem(tabName = "results",
        fluidRow(
          box(
            title = "Analysis Controls", status = "primary", solidHeader = TRUE, width = 12,
            fluidRow(
              column(4, selectInput("dataset_results", "Select Dataset:", choices = NULL)),
              column(4, selectInput("algorithm_results", "Select Algorithm:", choices = NULL)),
              column(4, br(), actionButton("run_analysis", "Run Analysis", class = "btn-primary", width = "100%"))
            )
          )
        ),

        fluidRow(
          box(
            title = "Training Progress", status = "info", solidHeader = TRUE, width = 12,
            verbatimTextOutput("training_progress")
          )
        ),

        fluidRow(
          box(
            title = "RMSE Comparison", status = "primary", solidHeader = TRUE, width = 12,
            plotlyOutput("rmse_comparison", height = "400px")
          )
        ),

        fluidRow(
          box(
            title = "Best Parameters - Genetic Algorithm", status = "success", solidHeader = TRUE, width = 6,
            verbatimTextOutput("genetic_params")
          ),

          box(
            title = "Best Parameters - Exhaustive Search", status = "warning", solidHeader = TRUE, width = 6,
            verbatimTextOutput("exhaustive_params")
          )
        ),

        fluidRow(
          box(
            title = "Results Summary", status = "primary", solidHeader = TRUE, width = 12,
            DT::dataTableOutput("results_table"),
            br(),
            downloadButton("download_excel", "Export to Excel", class = "btn-success")
          )
        )
      ),

      # Settings Tab
      tabItem(tabName = "settings",
        fluidRow(
          box(
            title = "Framework Configuration", status = "primary", solidHeader = TRUE, width = 12,
            tabBox(
              width = 12,
              tabPanel(
                title = "General Settings",
                icon = icon("cogs"),
                fluidRow(
                  column(6,
                    h4("System Configuration", style = "color: #3c8dbc;"),
                    numericInput("n_cores", "Number of CPU Cores:", 
                                value = detectCores() - 1, min = 1, max = detectCores()),
                    checkboxInput("use_parallel", "Enable Parallel Processing", value = TRUE),
                    
                    hr(),
                    h4("Cross-Validation Settings", style = "color: #3c8dbc;"),
                    numericInput("cv_folds", "Cross-Validation Folds:", 
                                value = 5, min = 3, max = 10),
                    numericInput("test_size", "Test Set Size (%):", 
                                value = 30, min = 10, max = 50)
                  ),
                  column(6,
                    h4("Performance Settings", style = "color: #3c8dbc;"),
                    selectInput("execution_mode", "Execution Mode:", 
                               choices = c("Quick" = "quick", "Balanced" = "balanced", "Thorough" = "thorough"),
                               selected = "balanced"),
                    checkboxInput("enable_logging", "Enable Detailed Logging", value = TRUE)
                  )
                )
              ),
              
              tabPanel(
                title = "Genetic Algorithm",
                icon = icon("dna"),
                div(
                  class = "alert alert-info",
                  style = "margin-bottom: 20px;",
                  HTML("<strong><i class='fa fa-info-circle'></i> Dataset-Specific Configuration:</strong><br>
                       GA parameters are automatically optimized for each dataset based on professor's specifications.<br>
                       Default values shown below are used as fallback for unknown datasets.<br>
                       <strong>Crossover:</strong> gareal_blxCrossover | <strong>Mutation:</strong> gareal_raMutation | <strong>Pcrossover:</strong> 0.85")
                ),
                fluidRow(
                  column(6,
                    h4("Population Settings", style = "color: #00a65a;"),
                    numericInput("ga_population", "Population Size:", 
                                value = 40, min = 5, max = 200),
                    numericInput("ga_generations", "Number of Generations:", 
                                value = 50, min = 3, max = 300),
                    numericInput("ga_runs", "Number of Runs:", 
                                value = 3, min = 1, max = 50),
                    
                    hr(),
                    h4("Genetic Operators", style = "color: #00a65a;"),
                    sliderInput("ga_mutation_rate", "Mutation Rate:", 
                               min = 0.01, max = 0.3, value = 0.15, step = 0.01),
                    sliderInput("ga_crossover_rate", "Crossover Rate:", 
                               min = 0.5, max = 0.95, value = 0.85, step = 0.05),
                    numericInput("ga_elitism_count", "Elitism Count:", 
                                value = 2, min = 1, max = 20),
                    sliderInput("ga_elite_percentage", "Elite Percentage:", 
                               min = 0.05, max = 0.3, value = 0.1, step = 0.05)
                  ),
                  column(6,
                    h4("Selection & Convergence", style = "color: #00a65a;"),
                    selectInput("ga_selection_method", "Selection Method:", 
                               choices = c("Tournament" = "tournament", 
                                         "Roulette" = "roulette", 
                                         "Rank" = "rank"),
                               selected = "tournament"),
                    numericInput("ga_tournament_size", "Tournament Size:", 
                                value = 3, min = 2, max = 10),
                    
                    hr(),
                    h4("Stopping Criteria", style = "color: #00a65a;"),
                    numericInput("ga_convergence_threshold", "Convergence Threshold:", 
                                value = 1e-6, min = 1e-8, max = 1e-3, step = 1e-6),
                    numericInput("ga_max_no_improvement", "Max Generations without Improvement:", 
                                value = 10, min = 3, max = 20)
                  )
                )
              ),
              
              tabPanel(
                title = "Exhaustive Search",
                icon = icon("search"),
                fluidRow(
                  column(6,
                    h4("Search Configuration", style = "color: #f39c12;"),
                    selectInput("exhaustive_grid_density", "Grid Density:", 
                               choices = c("Sparse (Fast)" = "sparse", 
                                         "Medium (Balanced)" = "medium", 
                                         "Dense (Thorough)" = "dense"),
                               selected = "medium"),
                    numericInput("exhaustive_max_combinations", "Max Combinations to Test:", 
                                value = 1000, min = 10, max = 10000),
                    
                    hr(),
                    h4("Time Limits", style = "color: #f39c12;"),
                    numericInput("exhaustive_timeout_minutes", "Maximum Runtime (minutes):", 
                                value = 30, min = 1, max = 180),
                    checkboxInput("exhaustive_enable_timeout", "Enable Timeout", value = TRUE)
                  ),
                  column(6,
                    h4("Early Stopping", style = "color: #f39c12;"),
                    checkboxInput("exhaustive_early_stopping", "Enable Early Stopping", value = TRUE),
                    numericInput("exhaustive_patience", "Patience (combinations without improvement):", 
                                value = 50, min = 10, max = 200),
                    numericInput("exhaustive_min_improvement", "Minimum Improvement Threshold:", 
                                value = 0.001, min = 0.0001, max = 0.01, step = 0.0001),
                    
                    hr(),
                    h4("Sampling Strategy", style = "color: #f39c12;"),
                    selectInput("exhaustive_sampling", "Parameter Sampling:", 
                               choices = c("Grid Search" = "grid", 
                                         "Random Search" = "random", 
                                         "Latin Hypercube" = "lhs"),
                               selected = "grid"),
                    conditionalPanel(
                      condition = "input.exhaustive_sampling == 'random'",
                      numericInput("exhaustive_random_samples", "Number of Random Samples:", 
                                  value = 100, min = 10, max = 1000)
                    )
                  )
                )
              ),
              
              tabPanel(
                title = "Algorithm Specific",
                icon = icon("wrench"),
                fluidRow(
                  column(12,
                    h4("Algorithm Parameter Ranges", style = "color: #dd4b39;"),
                    p("Configure parameter ranges for each machine learning algorithm:"),
                    
                    hr(),
                    
                    # RandomForest Settings
                    h5("Random Forest Settings", style = "color: #00a65a;"),
                    fluidRow(
                      column(4,
                        numericInput("rf_ntree_min", "Min Trees:", value = 50, min = 10, max = 500),
                        numericInput("rf_ntree_max", "Max Trees:", value = 200, min = 50, max = 1000)
                      ),
                      column(4,
                        numericInput("rf_mtry_min", "Min mtry:", value = 2, min = 1, max = 10),
                        numericInput("rf_mtry_max", "Max mtry:", value = 6, min = 2, max = 20)
                      ),
                      column(4,
                        numericInput("rf_nodesize_min", "Min Node Size:", value = 1, min = 1, max = 10),
                        numericInput("rf_nodesize_max", "Max Node Size:", value = 5, min = 1, max = 20)
                      )
                    ),
                    
                    hr(),
                    
                    # XGBoost Settings
                    h5("XGBoost Settings", style = "color: #3c8dbc;"),
                    fluidRow(
                      column(4,
                        numericInput("xgb_nrounds_min", "Min Rounds:", value = 50, min = 10, max = 200),
                        numericInput("xgb_nrounds_max", "Max Rounds:", value = 200, min = 50, max = 1000)
                      ),
                      column(4,
                        numericInput("xgb_max_depth_min", "Min Max Depth:", value = 3, min = 1, max = 6),
                        numericInput("xgb_max_depth_max", "Max Max Depth:", value = 7, min = 3, max = 15)
                      ),
                      column(4,
                        sliderInput("xgb_eta_min", "Min Learning Rate:", min = 0.001, max = 0.1, value = 0.01, step = 0.001),
                        sliderInput("xgb_eta_max", "Max Learning Rate:", min = 0.1, max = 0.5, value = 0.3, step = 0.01)
                      )
                    ),
                    
                    hr(),
                    
                    # KNN Settings
                    h5("K-Nearest Neighbors Settings", style = "color: #f39c12;"),
                    fluidRow(
                      column(6,
                        numericInput("knn_k_min", "Min K:", value = 3, min = 1, max = 10),
                        numericInput("knn_k_max", "Max K:", value = 11, min = 3, max = 50)
                      ),
                      column(6,
                        checkboxGroupInput("knn_algorithms", "Algorithms to Test:",
                                         choices = c("KD Tree" = "kd_tree", 
                                                   "Cover Tree" = "cover_tree", 
                                                   "Brute Force" = "brute"),
                                         selected = c("kd_tree", "brute"))
                      )
                    )
                  )
                )
              )
            ),
            
            hr(),
            fluidRow(
              column(6,
                actionButton("save_settings", "Save All Settings", class = "btn-success btn-lg", 
                            style = "width: 100%;", icon = icon("save"))
              ),
              column(6,
                actionButton("reset_settings", "Reset to Defaults", class = "btn-warning btn-lg", 
                            style = "width: 100%;", icon = icon("refresh"))
              )
            )
          )
        )
      )
    )
  )
)

# Define Server
server <- function(input, output, session) {
  # Initialize reactive values
  values <- reactiveValues(
    datasets = NULL,
    results_genetic = NULL,
    results_exhaustive = NULL,
    training_in_progress = FALSE,
    progress_message = "Ready to start analysis...",
    settings = list(
      # General settings
      n_cores = if(exists("N_CORES")) N_CORES else detectCores() - 1,
      use_parallel = if(exists("USE_PARALLEL")) USE_PARALLEL else TRUE,
      cv_folds = if(exists("CV_FOLDS")) CV_FOLDS else 5,
      test_size = if(exists("TEST_SIZE")) TEST_SIZE else 0.3,
      execution_mode = "balanced",
      enable_logging = TRUE,
      
      # Genetic Algorithm settings
      ga_population = if(exists("GA_POPULATION")) GA_POPULATION else 126,
      ga_generations = if(exists("GA_GENERATIONS")) GA_GENERATIONS else 100,
      ga_mutation_rate = 0.15,
      ga_crossover_rate = 0.85,
      ga_elite_percentage = 0.1,
      ga_elitism_count = 7,
      ga_runs = 30,
      ga_selection_method = "tournament",
      ga_tournament_size = 3,
      ga_convergence_threshold = 1e-6,
      ga_max_no_improvement = 10,
      
      # Exhaustive Search settings
      exhaustive_grid_density = "medium",
      exhaustive_max_combinations = 1000,
      exhaustive_timeout_minutes = 30,
      exhaustive_enable_timeout = TRUE,
      exhaustive_early_stopping = TRUE,
      exhaustive_patience = 50,
      exhaustive_min_improvement = 0.001,
      exhaustive_sampling = "grid",
      exhaustive_random_samples = 100,
      
      # Algorithm-specific settings
      rf_ntree_min = 50,
      rf_ntree_max = 200,
      rf_mtry_min = 2,
      rf_mtry_max = 6,
      rf_nodesize_min = 1,
      rf_nodesize_max = 5,
      
      xgb_nrounds_min = 50,
      xgb_nrounds_max = 200,
      xgb_max_depth_min = 3,
      xgb_max_depth_max = 7,
      xgb_eta_min = 0.01,
      xgb_eta_max = 0.3,
      
      knn_k_min = 3,
      knn_k_max = 11,
      knn_algorithms = c("kd_tree", "brute")
    )
  )

  # Load datasets on startup
  observe({
    print_application_header()
    print_section_header("Loading Datasets")

    # Load CSV files from datasets directory
    dataset_path <- file.path(getwd(), "datasets")
    csv_files <- list.files(dataset_path, pattern = "\\.csv$", full.names = TRUE)

    if (length(csv_files) > 0) {
      data_generator <- DataGenerator$new(csv_files)
      values$datasets <- data_generator$load_data()

      # Update UI choices
      dataset_names <- names(values$datasets)
      updateSelectInput(session, "dataset_eda", choices = dataset_names)
      updateSelectInput(session, "dataset_results", choices = dataset_names)

      print_success(paste("Successfully loaded", length(dataset_names), "datasets"))
    } else {
      showNotification("No CSV files found in datasets directory", type = "error")
    }
  })

  # Update algorithm choices when dataset is selected
  observeEvent(input$dataset_results, {
    if (!is.null(input$dataset_results) && input$dataset_results != "") {
      # Default algorithms available
      algorithms <- c("LinearRegression", "DecisionTree", "RandomForest",
                     "Lasso", "Ridge", "KNN", "XGBoost")
      updateSelectInput(session, "algorithm_results", choices = algorithms)
    }
  })

  # Update variable choices for EDA plots when dataset is selected
  observeEvent(input$dataset_eda, {
    if (!is.null(values$datasets) && !is.null(input$dataset_eda) && input$dataset_eda != "") {
      data <- values$datasets[[input$dataset_eda]]
      
      # Function to get detailed data type (same as in data summary)
      get_data_type <- function(x) {
        if (is.integer(x)) {
          return("int64")
        } else if (is.numeric(x)) {
          if (all(x == floor(x), na.rm = TRUE)) {
            return("int64")
          } else {
            return("float64")
          }
        } else if (is.character(x)) {
          return("string")
        } else if (is.factor(x)) {
          return("factor")
        } else if (is.logical(x)) {
          return("boolean")
        } else if (inherits(x, "Date")) {
          return("date")
        } else if (inherits(x, "POSIXt")) {
          return("datetime")
        } else {
          return(class(x)[1])
        }
      }
      
      # Get numeric columns for histogram
      numeric_cols <- names(data)[sapply(data, is.numeric)]
      if (length(numeric_cols) > 0) {
        # Create labels with specific data types
        numeric_labels <- sapply(numeric_cols, function(col) {
          data_type <- get_data_type(data[[col]])
          paste(col, "(", data_type, ")", sep = "")
        })
        
        updateSelectInput(session, "variable_histogram", 
                         choices = setNames(numeric_cols, numeric_labels),
                         selected = numeric_cols[1])
      } else {
        updateSelectInput(session, "variable_histogram", choices = NULL)
      }
      
      # Get all columns for boxplot (can work with both numeric and categorical)
      all_cols <- names(data)
      # Create labels with specific data types for all columns
      all_labels <- sapply(all_cols, function(col) {
        data_type <- get_data_type(data[[col]])
        paste(col, "(", data_type, ")", sep = "")
      })
      
      updateSelectInput(session, "variable_boxplot", 
                       choices = setNames(all_cols, all_labels),
                       selected = all_cols[1])
    }
  })

  # EDA outputs
  output$data_summary <- renderUI({
    if (!is.null(values$datasets) && !is.null(input$dataset_eda) && input$dataset_eda != "") {
      data <- values$datasets[[input$dataset_eda]]
      
      # Basic dataset information
      nrows <- nrow(data)
      ncols <- ncol(data)
      missing_total <- sum(is.na(data))
      missing_pct <- round((missing_total / (nrows * ncols)) * 100, 2)
      
      # Generate summary statistics for each column
      summary_html <- paste0(
        "<div class='data-summary-container' style='padding: 5px;'>",
        "<div class='overview-stats'>",
        "<h5 style='margin: 0 0 15px 0; color: #495057; font-weight: 600;'>",
        "<i class='fa fa-database' style='margin-right: 8px; color: #007bff;'></i>Dataset Overview</h5>",
        "<div style='display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: 12px;'>",
        "<div class='stat-badge' style='background: linear-gradient(135deg, #007bff, #0056b3); color: white;'>",
        "<i class='fa fa-table'></i> Rows: ", format(nrows, big.mark = ","), "</div>",
        "<div class='stat-badge' style='background: linear-gradient(135deg, #28a745, #1e7e34); color: white;'>",
        "<i class='fa fa-columns'></i> Columns: ", ncols, "</div>",
        "<div class='stat-badge' style='background: linear-gradient(135deg, #17a2b8, #117a8b); color: white;'>",
        "<i class='fa fa-hdd-o'></i> Size: ", format(object.size(data), units = "auto"), "</div>",
        if (missing_total > 0) {
          paste0("<div class='stat-badge' style='background: linear-gradient(135deg, #ffc107, #e0a800); color: #212529;'>",
                 "<i class='fa fa-exclamation-triangle'></i> Missing: ", missing_pct, "%</div>")
        } else {
          "<div class='stat-badge' style='background: linear-gradient(135deg, #28a745, #1e7e34); color: white;'><i class='fa fa-check-circle'></i> Complete</div>"
        },
        "</div></div>"
      )
      
      # Column-wise summary
      col_summaries <- ""
      numeric_cols <- sapply(data, is.numeric)
      
      # Function to get detailed data type
      get_data_type <- function(x) {
        if (is.integer(x)) {
          return("int64")
        } else if (is.numeric(x)) {
          # Check if all values are whole numbers (could be stored as double but are integers)
          if (all(x == floor(x), na.rm = TRUE)) {
            return("int64")
          } else {
            return("float64")
          }
        } else if (is.character(x)) {
          return("string")
        } else if (is.factor(x)) {
          return("factor")
        } else if (is.logical(x)) {
          return("boolean")
        } else if (inherits(x, "Date")) {
          return("date")
        } else if (inherits(x, "POSIXt")) {
          return("datetime")
        } else {
          return(class(x)[1])
        }
      }
      
      for (col_name in names(data)) {
        col_data <- data[[col_name]]
        data_type <- get_data_type(col_data)
        
        if (is.numeric(col_data)) {
          # Numeric column summary
          col_summary <- summary(col_data)
          std_dev <- round(sd(col_data, na.rm = TRUE), 3)
          
          col_summaries <- paste0(col_summaries,
            "<div class='summary-card' style='margin-bottom: 15px;'>",
            "<div class='summary-header'>",
            "<i class='fa fa-line-chart' style='margin-right: 8px;'></i>", 
            "<strong>", col_name, "</strong> <small style='opacity: 0.8;'>(", data_type, ")</small>",
            "</div>",
            "<div style='padding: 15px;'>",
            "<div class='stat-grid'>",
            "<div class='stat-item'><span class='stat-label'>Min:</span><span class='stat-value'>", round(col_summary[1], 3), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Q1:</span><span class='stat-value'>", round(col_summary[2], 3), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Median:</span><span class='stat-value'>", round(col_summary[3], 3), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Mean:</span><span class='stat-value'>", round(col_summary[4], 3), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Q3:</span><span class='stat-value'>", round(col_summary[5], 3), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Max:</span><span class='stat-value'>", round(col_summary[6], 3), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Std Dev:</span><span class='stat-value'>", std_dev, "</span></div>",
            if (sum(is.na(col_data)) > 0) {
              paste0("<div class='stat-item' style='background-color: #fff3cd; border-color: #ffeaa7;'>",
                     "<span class='stat-label'>Missing:</span><span style='color: #856404; font-weight: 600;'>", 
                     sum(is.na(col_data)), " (", round(sum(is.na(col_data))/length(col_data)*100, 1), "%)</span></div>")
            } else {
              "<div class='stat-item' style='background-color: #d4edda; border-color: #c3e6cb;'><span class='stat-label'>Missing:</span><span style='color: #155724; font-weight: 600;'>None</span></div>"
            },
            "</div></div></div>"
          )
        } else {
          # Categorical/Character column summary
          unique_vals <- length(unique(col_data[!is.na(col_data)]))
          if (length(table(col_data, useNA = "no")) > 0) {
            mode_val <- names(sort(table(col_data, useNA = "no"), decreasing = TRUE))[1]
            mode_count <- max(table(col_data, useNA = "no"))
            mode_pct <- round((mode_count / length(col_data[!is.na(col_data)])) * 100, 1)
          } else {
            mode_val <- "N/A"
            mode_count <- 0
            mode_pct <- 0
          }
          
          col_summaries <- paste0(col_summaries,
            "<div class='summary-card' style='margin-bottom: 15px;'>",
            "<div class='summary-header categorical'>",
            "<i class='fa fa-tags' style='margin-right: 8px;'></i>", 
            "<strong>", col_name, "</strong> <small style='opacity: 0.8;'>(", data_type, ")</small>",
            "</div>",
            "<div style='padding: 15px;'>",
            "<div class='stat-grid'>",
            "<div class='stat-item'><span class='stat-label'>Unique:</span><span class='stat-value'>", unique_vals, "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Most Frequent:</span><span class='stat-value'>", 
            ifelse(nchar(mode_val) > 15, paste0(substr(mode_val, 1, 15), "..."), mode_val), "</span></div>",
            "<div class='stat-item'><span class='stat-label'>Frequency:</span><span class='stat-value'>", mode_count, " (", mode_pct, "%)</span></div>",
            "<div class='stat-item'><span class='stat-label'>Total:</span><span class='stat-value'>", length(col_data), "</span></div>",
            if (sum(is.na(col_data)) > 0) {
              paste0("<div class='stat-item' style='background-color: #fff3cd; border-color: #ffeaa7;'>",
                     "<span class='stat-label'>Missing:</span><span style='color: #856404; font-weight: 600;'>", 
                     sum(is.na(col_data)), " (", round(sum(is.na(col_data))/length(col_data)*100, 1), "%)</span></div>")
            } else {
              "<div class='stat-item' style='background-color: #d4edda; border-color: #c3e6cb;'><span class='stat-label'>Missing:</span><span style='color: #155724; font-weight: 600;'>None</span></div>"
            },
            "</div></div></div>"
          )
        }
      }
      
      final_html <- paste0(summary_html, col_summaries, "</div>")
      HTML(final_html)
    }
  })

  output$missing_values <- DT::renderDataTable({
    if (!is.null(values$datasets) && !is.null(input$dataset_eda) && input$dataset_eda != "") {
      data <- values$datasets[[input$dataset_eda]]
      
      # Create missing values summary with only two columns
      missing_counts <- sapply(data, function(x) sum(is.na(x)))
      
      missing_df <- data.frame(
        Column = names(data),
        Missing_Count = missing_counts,
        stringsAsFactors = FALSE
      )
      
      # Remove row names to avoid duplication
      rownames(missing_df) <- NULL
      
      missing_df
    }
  }, options = list(
    pageLength = 10, 
    searching = FALSE,
    columnDefs = list(
      list(targets = 0, title = "Column"),
      list(targets = 1, title = "Missing Count")
    )
  ))

  output$correlation_heatmap <- renderPlotly({
    if (!is.null(values$datasets) && !is.null(input$dataset_eda) && input$dataset_eda != "") {
      data <- values$datasets[[input$dataset_eda]]
      numeric_data <- data[sapply(data, is.numeric)]

      if (ncol(numeric_data) > 1) {
        corr_matrix <- cor(numeric_data, use = "complete.obs")

        plot_ly(
          z = ~corr_matrix,
          type = "heatmap",
          colorscale = "RdBu",
          zmin = -1,
          zmax = 1,
          showscale = TRUE
        ) %>%
          layout(
            title = paste("Correlation Heatmap -", input$dataset_eda),
            xaxis = list(title = ""),
            yaxis = list(title = "")
          )
      }
    }
  })

  output$histogram_plot <- renderPlotly({
    if (!is.null(values$datasets) && !is.null(input$dataset_eda) && input$dataset_eda != "" &&
        !is.null(input$variable_histogram) && input$variable_histogram != "") {
      
      data <- values$datasets[[input$dataset_eda]]
      col_name <- input$variable_histogram
      
      if (col_name %in% names(data) && is.numeric(data[[col_name]])) {
        # Create professional histogram
        col_data <- data[[col_name]]
        
        # Calculate statistics for better binning
        n_bins <- min(50, max(10, ceiling(sqrt(length(col_data[!is.na(col_data)])))))
        
        # Create histogram with custom styling
        p <- plot_ly(
          x = col_data,
          type = "histogram",
          nbinsx = n_bins,
          marker = list(
            color = "#3498db",
            line = list(color = "#2980b9", width = 1)
          ),
          opacity = 0.8,
          name = "Frequency"
        )
        
        # Add mean line and layout
        mean_val <- mean(col_data, na.rm = TRUE)
        p <- p %>%
        layout(
          title = list(
            text = paste("<b>Distribution of", col_name, "</b>"),
            font = list(size = 16, family = "Arial")
          ),
          xaxis = list(
            title = list(text = col_name, font = list(size = 14)),
            showgrid = TRUE,
            gridcolor = "#ecf0f1"
          ),
          yaxis = list(
            title = list(text = "Frequency", font = list(size = 14)),
            showgrid = TRUE,
            gridcolor = "#ecf0f1"
          ),
          plot_bgcolor = "#ffffff",
          paper_bgcolor = "#ffffff",
          hovermode = "x unified",
          showlegend = FALSE,
          shapes = list(
            list(
              type = "line",
              x0 = mean_val, x1 = mean_val,
              y0 = 0, y1 = 1,
              yref = "paper",
              line = list(color = "#e74c3c", width = 2, dash = "dash")
            )
          ),
          annotations = list(
            list(
              x = mean_val,
              y = 0.9,
              yref = "paper",
              text = paste("Mean:", round(mean_val, 2)),
              showarrow = TRUE,
              arrowhead = 2,
              arrowcolor = "#e74c3c",
              font = list(color = "#e74c3c", size = 12),
              bgcolor = "rgba(255,255,255,0.8)",
              bordercolor = "#e74c3c",
              borderwidth = 1
            )
          )
        ) %>%
        config(displayModeBar = TRUE, modeBarButtonsToRemove = c("pan2d", "select2d", "lasso2d"))
        
        p
      } else {
        # Show message if variable is not numeric
        plot_ly() %>%
          layout(
            title = "Please select a numeric variable for histogram",
            xaxis = list(visible = FALSE),
            yaxis = list(visible = FALSE),
            annotations = list(
              text = "No numeric variable selected",
              x = 0.5, y = 0.5,
              xref = "paper", yref = "paper",
              showarrow = FALSE,
              font = list(size = 16, color = "#7f8c8d")
            )
          )
      }
    }
  })

  output$boxplot <- renderPlotly({
    if (!is.null(values$datasets) && !is.null(input$dataset_eda) && input$dataset_eda != "" &&
        !is.null(input$variable_boxplot) && input$variable_boxplot != "") {
      
      data <- values$datasets[[input$dataset_eda]]
      col_name <- input$variable_boxplot
      
      if (col_name %in% names(data)) {
        col_data <- data[[col_name]]
        
        if (is.numeric(col_data)) {
          # Numeric boxplot
          p <- plot_ly(
            y = col_data,
            type = "box",
            marker = list(color = "#2ecc71"),
            line = list(color = "#27ae60"),
            name = col_name,
            boxpoints = "outliers",
            pointpos = 0
          ) %>%
          layout(
            title = list(
              text = paste("<b>Box Plot of", col_name, "</b>"),
              font = list(size = 16, family = "Arial")
            ),
            yaxis = list(
              title = list(text = col_name, font = list(size = 14)),
              showgrid = TRUE,
              gridcolor = "#ecf0f1"
            ),
            xaxis = list(
              title = list(text = "", font = list(size = 14)),
              showticklabels = FALSE
            ),
            plot_bgcolor = "#ffffff",
            paper_bgcolor = "#ffffff",
            showlegend = FALSE
          )
        } else {
          # Categorical variable - show value counts as bar plot
          freq_table <- table(col_data, useNA = "ifany")
          freq_df <- data.frame(
            Category = names(freq_table),
            Count = as.numeric(freq_table)
          )
          
          p <- plot_ly(
            data = freq_df,
            x = ~Category,
            y = ~Count,
            type = "bar",
            marker = list(color = "#9b59b6", line = list(color = "#8e44ad", width = 1))
          ) %>%
          layout(
            title = list(
              text = paste("<b>Distribution of", col_name, "</b>"),
              font = list(size = 16, family = "Arial")
            ),
            xaxis = list(
              title = list(text = col_name, font = list(size = 14)),
              showgrid = FALSE
            ),
            yaxis = list(
              title = list(text = "Count", font = list(size = 14)),
              showgrid = TRUE,
              gridcolor = "#ecf0f1"
            ),
            plot_bgcolor = "#ffffff",
            paper_bgcolor = "#ffffff",
            showlegend = FALSE
          )
        }
        
        p %>% config(displayModeBar = TRUE, modeBarButtonsToRemove = c("pan2d", "select2d", "lasso2d"))
      }
    }
  })

  # Model training and results
  observeEvent(input$run_analysis, {
    if (!is.null(values$datasets) && !is.null(input$dataset_results) &&
        !is.null(input$algorithm_results) && !values$training_in_progress) {

      values$training_in_progress <- TRUE

      # Show progress
      output$training_progress <- renderText({
        "Training in progress... This may take several minutes."
      })

      # Run analysis synchronously for now (can be made async later)
      tryCatch({
        # Get dataset-specific GA configuration
        dataset_ga_config <- get_dataset_ga_config(input$dataset_results)
        
        # Update settings with dataset-specific parameters
        updated_settings <- values$settings
        updated_settings$ga_population <- dataset_ga_config$popSize
        updated_settings$ga_generations <- dataset_ga_config$maxiter
        updated_settings$ga_crossover_rate <- dataset_ga_config$pcrossover
        updated_settings$ga_mutation_rate <- dataset_ga_config$pmutation
        updated_settings$ga_elitism_count <- dataset_ga_config$elitism
        updated_settings$ga_runs <- dataset_ga_config$run
        
        print(paste("Using GA config for", input$dataset_results, ":"))
        print(paste("Population:", dataset_ga_config$popSize))
        print(paste("Generations:", dataset_ga_config$maxiter))
        print(paste("Crossover rate:", dataset_ga_config$pcrossover))
        print(paste("Mutation rate:", dataset_ga_config$pmutation))
        print(paste("Elitism:", dataset_ga_config$elitism))
        print(paste("Runs:", dataset_ga_config$run))
        
        main_controller <- MainController$new()
        results <- main_controller$run_analysis(
          datasets = values$datasets,
          selected_dataset = input$dataset_results,
          selected_algorithm = input$algorithm_results,
          settings = updated_settings
        )

        values$results_genetic <- results$genetic
        values$results_exhaustive <- results$exhaustive
        values$training_in_progress <- FALSE

        output$training_progress <- renderText({
          "Training completed successfully!"
        })

        showNotification("Model training completed!", type = "message")

      }, error = function(e) {
        values$training_in_progress <- FALSE
        output$training_progress <- renderText({
          paste("Error during training:", e$message)
        })
        showNotification(paste("Training failed:", e$message), type = "error")
      })
    }
  })

  # Display results
  output$rmse_comparison <- renderPlotly({
    if (!is.null(values$results_genetic) && !is.null(values$results_exhaustive)) {
      # Create comparison plot
      genetic_rmse <- values$results_genetic$rmse
      exhaustive_rmse <- values$results_exhaustive$rmse

      plot_ly() %>%
        add_bars(x = c("Genetic", "Exhaustive"), y = c(genetic_rmse, exhaustive_rmse),
                name = "RMSE", marker = list(color = c("blue", "red"))) %>%
        layout(title = "RMSE Comparison: Genetic vs Exhaustive Search",
               xaxis = list(title = "Method"),
               yaxis = list(title = "RMSE"))
    }
  })

  output$genetic_params <- renderPrint({
    if (!is.null(values$results_genetic)) {
      values$results_genetic$best_params
    }
  })

  output$exhaustive_params <- renderPrint({
    if (!is.null(values$results_exhaustive)) {
      values$results_exhaustive$best_params
    }
  })

  output$results_table <- DT::renderDataTable({
    if (!is.null(values$results_genetic) && !is.null(values$results_exhaustive)) {
      results_df <- data.frame(
        Method = c("Genetic Algorithm", "Exhaustive Search"),
        RMSE = c(values$results_genetic$rmse, values$results_exhaustive$rmse),
        R2_Score = c(values$results_genetic$r2, values$results_exhaustive$r2),
        Training_Time = c(values$results_genetic$training_time, values$results_exhaustive$training_time)
      )
      results_df
    }
  }, options = list(pageLength = 10))

  # Download handler for Excel export
  output$download_excel <- downloadHandler(
    filename = function() {
      paste0("framework_results_", Sys.Date(), ".xlsx")
    },
    content = function(file) {
      if (!is.null(values$results_genetic) && !is.null(values$results_exhaustive)) {
        # Create workbook and export results
        wb <- createWorkbook()

        # General results sheet
        results_df <- data.frame(
          Method = c("Genetic Algorithm", "Exhaustive Search"),
          RMSE = c(values$results_genetic$rmse, values$results_exhaustive$rmse),
          R2_Score = c(values$results_genetic$r2, values$results_exhaustive$r2),
          Training_Time = c(values$results_genetic$training_time, values$results_exhaustive$training_time)
        )

        addWorksheet(wb, "General Results")
        writeData(wb, "General Results", results_df)

        # Save workbook
        saveWorkbook(wb, file, overwrite = TRUE)
      }
    }
  )

  # Settings management
  observeEvent(input$save_settings, {
    values$settings <- list(
      # General settings
      general = list(
        n_cores = input$n_cores,
        use_parallel = input$use_parallel,
        cv_folds = input$cv_folds,
        test_size = input$test_size / 100,
        execution_mode = input$execution_mode,
        enable_logging = input$enable_logging
      ),
      
      # Genetic Algorithm settings
      genetic_algorithm = list(
        population_size = input$ga_population,
        generations = input$ga_generations,
        mutation_rate = input$ga_mutation_rate,
        crossover_rate = input$ga_crossover_rate,
        elite_percentage = input$ga_elite_percentage,
        elitism_count = if(!is.null(input$ga_elitism_count)) input$ga_elitism_count else 7,
        runs = if(!is.null(input$ga_runs)) input$ga_runs else 30,
        selection_method = input$ga_selection_method,
        tournament_size = input$ga_tournament_size,
        convergence_threshold = input$ga_convergence_threshold,
        max_no_improvement = input$ga_max_no_improvement
      ),
      
      # Exhaustive Search settings
      exhaustive_search = list(
        grid_density = input$exhaustive_grid_density,
        max_combinations = input$exhaustive_max_combinations,
        timeout_minutes = input$exhaustive_timeout_minutes,
        enable_timeout = input$exhaustive_enable_timeout,
        early_stopping = input$exhaustive_early_stopping,
        patience = input$exhaustive_patience,
        min_improvement = input$exhaustive_min_improvement,
        sampling_strategy = input$exhaustive_sampling,
        random_samples = if(!is.null(input$exhaustive_random_samples)) input$exhaustive_random_samples else 100
      ),
      
      # Algorithm-specific settings
      algorithm_specific = list(
        rf_ntree_range = c(input$rf_ntree_min, input$rf_ntree_max),
        rf_mtry_range = c(input$rf_mtry_min, input$rf_mtry_max),
        rf_nodesize_range = c(input$rf_nodesize_min, input$rf_nodesize_max),
        
        xgb_nrounds_range = c(input$xgb_nrounds_min, input$xgb_nrounds_max),
        xgb_max_depth_range = c(input$xgb_max_depth_min, input$xgb_max_depth_max),
        xgb_eta_range = c(input$xgb_eta_min, input$xgb_eta_max),
        
        knn_k_range = c(input$knn_k_min, input$knn_k_max),
        knn_algorithms = if(!is.null(input$knn_algorithms)) input$knn_algorithms else c("kd_tree", "brute")
      ),
      
      # Legacy settings for backward compatibility
      n_cores = input$n_cores,
      use_parallel = input$use_parallel,
      cv_folds = input$cv_folds,
      test_size = input$test_size / 100,
      ga_population = input$ga_population,
      ga_generations = input$ga_generations
    )
    showNotification("All settings saved successfully!", type = "message")
  })
  
  # Reset settings to defaults
  observeEvent(input$reset_settings, {
    showModal(modalDialog(
      title = "Reset Settings",
      "Are you sure you want to reset all settings to default values? This action cannot be undone.",
      footer = tagList(
        modalButton("Cancel"),
        actionButton("confirm_reset", "Reset", class = "btn-danger")
      )
    ))
  })
  
  # Confirm reset settings
  observeEvent(input$confirm_reset, {
    # Reset all input values to defaults
    updateNumericInput(session, "n_cores", value = detectCores() - 1)
    updateCheckboxInput(session, "use_parallel", value = TRUE)
    updateNumericInput(session, "cv_folds", value = 5)
    updateNumericInput(session, "test_size", value = 30)
    updateSelectInput(session, "execution_mode", selected = "balanced")
    updateCheckboxInput(session, "enable_logging", value = TRUE)
    
    # Reset GA settings - Optimized values
    updateNumericInput(session, "ga_population", value = 40)
    updateNumericInput(session, "ga_generations", value = 50)
    updateNumericInput(session, "ga_runs", value = 3)
    updateSliderInput(session, "ga_mutation_rate", value = 0.15)
    updateSliderInput(session, "ga_crossover_rate", value = 0.85)
    updateNumericInput(session, "ga_elitism_count", value = 2)
    updateSliderInput(session, "ga_elite_percentage", value = 0.1)
    updateSelectInput(session, "ga_selection_method", selected = "tournament")
    updateNumericInput(session, "ga_tournament_size", value = 3)
    updateNumericInput(session, "ga_convergence_threshold", value = 1e-6)
    updateNumericInput(session, "ga_max_no_improvement", value = 10)
    
    # Reset Exhaustive settings
    updateSelectInput(session, "exhaustive_grid_density", selected = "medium")
    updateNumericInput(session, "exhaustive_max_combinations", value = 1000)
    updateNumericInput(session, "exhaustive_timeout_minutes", value = 30)
    updateCheckboxInput(session, "exhaustive_enable_timeout", value = TRUE)
    updateCheckboxInput(session, "exhaustive_early_stopping", value = TRUE)
    updateNumericInput(session, "exhaustive_patience", value = 50)
    updateNumericInput(session, "exhaustive_min_improvement", value = 0.001)
    updateSelectInput(session, "exhaustive_sampling", selected = "grid")
    updateNumericInput(session, "exhaustive_random_samples", value = 100)
    
    # Reset algorithm-specific settings
    updateNumericInput(session, "rf_ntree_min", value = 50)
    updateNumericInput(session, "rf_ntree_max", value = 200)
    updateNumericInput(session, "rf_mtry_min", value = 2)
    updateNumericInput(session, "rf_mtry_max", value = 6)
    updateNumericInput(session, "rf_nodesize_min", value = 1)
    updateNumericInput(session, "rf_nodesize_max", value = 5)
    
    updateNumericInput(session, "xgb_nrounds_min", value = 50)
    updateNumericInput(session, "xgb_nrounds_max", value = 200)
    updateNumericInput(session, "xgb_max_depth_min", value = 3)
    updateNumericInput(session, "xgb_max_depth_max", value = 7)
    updateSliderInput(session, "xgb_eta_min", value = 0.01)
    updateSliderInput(session, "xgb_eta_max", value = 0.3)
    
    updateNumericInput(session, "knn_k_min", value = 3)
    updateNumericInput(session, "knn_k_max", value = 11)
    updateCheckboxGroupInput(session, "knn_algorithms", selected = c("kd_tree", "brute"))
    
    # Reset internal settings
    values$settings <- list(
      # General settings
      n_cores = detectCores() - 1,
      use_parallel = TRUE,
      cv_folds = 5,
      test_size = 0.3,
      execution_mode = "balanced",
      enable_logging = TRUE,
      
      # Genetic Algorithm settings - Ultra-fast execution with 3 runs
      ga_population = 40,
      ga_generations = 50,
      ga_mutation_rate = 0.15,
      ga_crossover_rate = 0.85,
      ga_elite_percentage = 0.1,
      ga_elitism_count = 2,
      ga_runs = 3,
      ga_selection_method = "tournament",
      ga_tournament_size = 3,
      ga_convergence_threshold = 1e-6,
      ga_max_no_improvement = 10,
      
      # Exhaustive Search settings
      exhaustive_grid_density = "medium",
      exhaustive_max_combinations = 1000,
      exhaustive_timeout_minutes = 30,
      exhaustive_enable_timeout = TRUE,
      exhaustive_early_stopping = TRUE,
      exhaustive_patience = 50,
      exhaustive_min_improvement = 0.001,
      exhaustive_sampling = "grid",
      exhaustive_random_samples = 100,
      
      # Algorithm-specific settings
      rf_ntree_min = 50,
      rf_ntree_max = 200,
      rf_mtry_min = 2,
      rf_mtry_max = 6,
      rf_nodesize_min = 1,
      rf_nodesize_max = 5,
      
      xgb_nrounds_min = 50,
      xgb_nrounds_max = 200,
      xgb_max_depth_min = 3,
      xgb_max_depth_max = 7,
      xgb_eta_min = 0.01,
      xgb_eta_max = 0.3,
      
      knn_k_min = 3,
      knn_k_max = 11,
      knn_algorithms = c("kd_tree", "brute")
    )
    
    removeModal()
    showNotification("All settings have been reset to default values!", type = "message")
  })
}

# Run the application
shinyApp(ui = ui, server = server)




# Add UI control into existing settings box if possible
if (exists("ui") && is.list(ui)) {
  # no-op if ui not easily editable here
}



# ---- RF flag server wrapper (idempotent) & robust return ----
if (exists("server", inherits = TRUE)) {
  already_wrapped <- isTRUE(attr(server, "rf_wrapped"))
  if (!already_wrapped) {
    server_old <- server
    server <- function(input, output, session) {
      # Ejecuta el server original
      if (length(formals(server_old)) >= 3) {
        server_old(input, output, session)
      } else {
        server_old()
      }
      # Aplica flag RF si existe en la UI
      observeEvent(input$rf_force_sequential, { options(rf_force_sequential = isTRUE(input$rf_force_sequential)) }, ignoreInit = FALSE)
    }
    attr(server, "rf_wrapped") <- TRUE
  }
}

# Fallbacks mínimos solo si faltan definiciones
if (!exists("ui", inherits = TRUE)) {
  ui <- shiny::fluidPage(
    shiny::h3("OptimML Framework"),
    shiny::p("UI principal no cargó. Verifica components/*.R"),
    shiny::checkboxInput("rf_force_sequential",
      "Forzar secuencial para RandomForest (macOS/Shiny recomendado)",
      value = TRUE
    )
  )
}
if (!exists("server", inherits = TRUE)) {
  server <- function(input, output, session) {
  observeEvent(input$rf_force_sequential, {
    options(rf_force_sequential = isTRUE(input$rf_force_sequential))
  }, ignoreInit = FALSE)
}
}

# Plan de futures seguro
if (requireNamespace("future", quietly = TRUE)) {
  future::plan(future::multisession)
}

shiny::shinyApp(ui = ui, server = server)

