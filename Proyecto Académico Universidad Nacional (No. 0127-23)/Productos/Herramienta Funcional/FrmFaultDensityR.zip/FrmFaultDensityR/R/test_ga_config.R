# Test script para verificar la configuración del GA
# Este script verifica que las configuraciones se carguen correctamente

# Cargar configuraciones
source("ga_config.R")

cat("=== VERIFICACIÓN DE CONFIGURACIÓN GA ===\n\n")

# Verificar que las configuraciones se cargaron
if (exists("GA_DATASET_CONFIGS")) {
  cat("✓ Configuraciones de datasets cargadas correctamente\n")
  cat("Número de datasets configurados:", length(GA_DATASET_CONFIGS), "\n\n")
} else {
  cat("✗ Error: No se pudieron cargar las configuraciones\n")
}

# Verificar operadores globales
if (exists("GA_CROSSOVER_OPERATOR") && exists("GA_MUTATION_OPERATOR")) {
  cat("✓ Operadores GA configurados:\n")
  cat("  Crossover:", GA_CROSSOVER_OPERATOR, "\n")
  cat("  Mutation:", GA_MUTATION_OPERATOR, "\n")
  cat("  Base Pcrossover:", GA_BASE_PCROSSOVER, "\n\n")
} else {
  cat("✗ Error: Operadores GA no configurados\n")
}

# Verificar algunas configuraciones específicas
test_datasets <- c("ant-1", "camel-1", "ivy-2", "jedit-4D")

cat("=== CONFIGURACIONES ESPECÍFICAS ===\n")
for (dataset in test_datasets) {
  if (dataset %in% names(GA_DATASET_CONFIGS)) {
    config <- GA_DATASET_CONFIGS[[dataset]]
    cat("Dataset:", dataset, "\n")
    cat("  Population Size:", config$popSize, "\n")
    cat("  Max Iterations:", config$maxiter, "\n")
    cat("  Crossover Rate:", config$pcrossover, "\n")
    cat("  Mutation Rate:", config$pmutation, "\n")
    cat("  Elitism:", config$elitism, "\n")
    cat("  Runs:", config$run, "\n")
    cat("  Samples:", config$n_samples, ", Features:", config$n_features, "\n\n")
  } else {
    cat("✗ Dataset", dataset, "no configurado\n")
  }
}

# Función de prueba para get_dataset_ga_config
source("app_functions.R", local = TRUE) # Cargar solo las funciones necesarias

cat("=== PRUEBA DE FUNCIÓN GET_DATASET_GA_CONFIG ===\n")
test_configs <- c("ant-1.csv", "camel-1.csv", "unknown-dataset.csv")

for (test_file in test_configs) {
  cat("Probando con archivo:", test_file, "\n")
  
  # Simular la función get_dataset_ga_config
  base_name <- tools::file_path_sans_ext(basename(test_file))
  
  if (exists("GA_DATASET_CONFIGS") && base_name %in% names(GA_DATASET_CONFIGS)) {
    config <- GA_DATASET_CONFIGS[[base_name]]
    cat("  ✓ Configuración encontrada para", base_name, "\n")
    cat("    PopSize:", config$popSize, "MaxIter:", config$maxiter, "Runs:", config$run, "\n")
  } else if (exists("GA_DEFAULT_CONFIG")) {
    config <- GA_DEFAULT_CONFIG
    cat("  ⚠ Usando configuración por defecto para", base_name, "\n")
    cat("    PopSize:", config$popSize, "MaxIter:", config$maxiter, "Runs:", config$run, "\n")
  } else {
    cat("  ✗ No se pudo obtener configuración para", base_name, "\n")
  }
  cat("\n")
}

cat("=== VERIFICACIÓN COMPLETA ===\n")
cat("Configuración lista para usar en OptimML Framework\n")